---
name: "gapit-expert"
description: "GAPIT GWAS/GS expert skill for installation, parameter tuning, result interpretation, and code support. Invoke when users ask about GAPIT, GWAS, GS, BLINK, FarmCPU, GAGBLUP, or output files."
---

# GAPIT专家技能

## 定位
这是一个面向 `TRAE workspace` 的本地技能，不再依赖单独的智能体外壳。当前工作区中的 `.trae/skills/gapit-expert/` 就是主技能目录，打开这个项目后即可作为 `skill` 被直接调用。

## 调用条件
在以下情况应优先调用本技能：
- 用户询问 GAPIT 安装、配置、依赖包和环境问题
- 用户需要 GWAS、GS、GAGBLUP、BLINK、FarmCPU 等方法建议
- 用户需要生成或检查 GAPIT R 代码
- 用户需要解释曼哈顿图、QQ 图、Kansas/NYC、预测结果文件
- 用户反馈 GAPIT 输出异常、文件覆盖、参数含义不清或结果与文献不符

## 调用方式
在 `TRAE Chat` 或工作区对话中，可通过以下方式触发：
- 直接提问 GAPIT 相关问题
- 明确点名 `gapit-expert`
- 在需要 GWAS/GS 诊断、代码生成、结果解读时自动调用本技能

## 主理人模式
本项目默认采用“本机工作区主理人模式”维护：
- 主维护副本路径：`/Users/Jiabo/Documents/trae_projects/GAPIT-Agent/.trae/skills/gapit-expert`
- 当前电脑和当前账户上的这个目录是升级入口和事实来源
- 所有新增知识、反馈整理、案例更新、函数说明修订，都先改这里
- 对外分发时，从这个目录打包导出版本快照
- 若需要修改 `gapit_functions.txt`，必须先征得用户确认，保留原始备份，并记录修改原因

## 维护原则
- 稳定知识写入主 `SKILL.md`
- 新反馈先整理再合并，避免未经验证的经验直接进入主规则
- 每次迭代建议带版本号和更新说明
- 若 `TRAE` 平台模型策略变化，优先保持本技能兼容 `Chat` 模式调用

## 邮件学习沉淀

以下规则来自真实支持邮件的第一轮提炼，详细沉淀见 `EMAIL_LEARNING_RULES.md`。这些规则应优先作为技能的“诊断顺序”和“回答偏好”，而不是仅作为案例收藏。

### 诊断顺序
1. 先判断用户的基因型输入类型：`HapMap` 还是 `numeric matrix`
2. 再检查 `phenotype / genotype / map` 的样本ID和数量是否一致
3. 再看是否属于旧版函数、旧教程或本地脚本过时导致的问题
4. 最后再进入模型级解释，如 `FarmCPU`、`BLINK`、`MLM`、`GS`

### 关键规则
- **数值型基因型**：优先建议用 `GD=` 和 `GM=`，不要机械套用 `G=`
- **HapMap读入**：若用户手动读表，必须提醒核对 `header`
- **安装/结果异常**：优先建议重新 `source()` 最新 `gapit_functions.txt`
- **FarmCPU报错**：优先排查重复 SNP、无变异 SNP、极低多态位点
- **个体数不一致**：优先检查 `genotype / map / phenotype` 对齐，而非先改模型参数
- **卡在预处理或可视化**：可尝试 `Geno.View.output=FALSE`
- **LD decay异常**：除了数据质量，也要检查函数版本是否过旧
- **PVE偏低或为 `NA`**：先解释模型机制，不要直接判定分析失败
- **BLINK/FarmCPU效应值问题**：多位点模型不一定提供传统单标记效应量，可引导用户看 `PVE` 和显著位点集合
- **单染色体 vs 全基因组差异**：对多位点迭代模型属于可能现象，正式结果优先建议全基因组整体分析

## 核心能力

### 1. GAPIT软件使用指导
- GAPIT安装和配置
- 数据格式准备和检查
- 参数设置和优化
- 常见错误排查

### 2. 遗传关联分析策略
- GWAS（全基因组关联分析）设计
- 群体结构校正
- 多重检验校正
- 结果解释和可视化

### 3. 数据分析支持
- 基因型数据质量控制
- 表型数据处理
- 关联分析模型选择
- 结果验证和复制

### 4. 问题诊断和解决
- 错误信息解读
- 性能优化建议
- 数据兼容性问题
- 软件版本问题

## 典型应用场景

### 场景1：GAPIT安装问题
用户遇到GAPIT安装失败或依赖包问题。

**处理流程：**
1. 检查R版本和依赖包
2. 验证GAPIT包安装状态
3. 提供安装命令和解决方案
4. 测试安装是否成功

### 场景2：数据分析错误
用户运行GAPIT时遇到错误或警告。

**处理流程：**
1. 分析错误信息和日志
2. 检查数据格式和完整性
3. 调整参数设置
4. 提供替代方案

### 场景3：结果解释
用户需要帮助理解GAPIT输出结果。

**处理流程：**
1. 解释主要输出文件内容
2. 指导如何识别显著位点
3. 提供结果可视化建议
4. 建议后续验证步骤

### 场景4：分析策略咨询
用户需要设计遗传关联分析实验。

**处理流程：**
1. 了解研究目标和数据特点
2. 推荐合适的分析模型
3. 建议样本量和统计功效
4. 提供质量控制标准

## 数据格式要求

### 输入文件格式
1. **基因型数据**：HapMap格式、PLINK格式、VCF格式
2. **表型数据**：CSV格式，包含样本ID和表型值
3. **协变量**：可选，用于校正群体结构
4. **亲缘关系矩阵**：可选，用于混合线性模型

### 输出文件说明
1. **GWAS.Results.csv**：主要关联分析结果
2. **GAPIT.Manhattan.png**：曼哈顿图
3. **GAPIT.QQ.png**：QQ图
4. **GAPIT.PCA.png**：主成分分析图

## 常见问题解决

### Q1: GAPIT安装失败
**可能原因：** R版本不兼容、依赖包缺失、权限问题
**解决方案：** 
```r
# 更新R到最新版本
# 安装必要依赖包
install.packages(c("devtools", "ggplot2", "reshape2", "scales"))
# 从GitHub安装GAPIT
devtools::install_github("jiabowang/GAPIT")
```

### Q2: 内存不足错误
**可能原因：** 数据量过大、内存分配不足
**解决方案：**
1. 增加R内存限制：`memory.limit(size=16000)`
2. 使用CMLM或FarmCPU等内存优化模型
3. 分批处理数据或使用子集分析

### Q3: 结果不显著
**可能原因：** 样本量不足、表型遗传力低、模型选择不当
**解决方案：**
1. 增加样本量或进行荟萃分析
2. 尝试不同模型（MLM、FarmCPU、BLINK）
3. 检查数据质量控制步骤

### Q4: file.output参数使用注意事项
**参数作用：** 控制GAPIT是否生成结果文件
- **file.output=TRUE**: 分析结果输出为文件（默认）
- **file.output=FALSE**: 不输出任何结果文件

**重要注意事项：**
1. **多性状分析时的文件覆盖问题**：
   - 当表型文件包含多个性状时，GAPIT会依次输出所有性状的分析结果
   - 不同性状的GAPIT结果文件名相同，会被后续分析覆盖
   - 建议为每个性状创建独立的输出目录

2. **循环分析时的优化**：
   - 基因型数据分析、分子亲缘关系、PCA等只会在第一次分析时生成
   - 后续性状分析会复用这些结果，提高效率
   - 但需要注意文件命名冲突问题

3. **最佳实践代码示例**：
```r
# 多性状分析，避免文件覆盖
trait_names <- colnames(phenotype_data)[-1]  # 假设第一列是Taxa

for(i in 1:length(trait_names)) {
  trait <- trait_names[i]
  
  # 为每个性状创建独立输出目录
  output_dir <- paste0("GAPIT_Output_", trait)
  dir.create(output_dir, showWarnings = FALSE)
  
  # 运行GAPIT分析
  myGAPIT <- GAPIT(
    Y = phenotype_data[, c(1, i+1)],  # Taxa列 + 当前性状列
    G = genotype_data,
    PCA.total = 5,
    model = "MLM",
    file.output = TRUE,
    file.path = output_dir  # 指定输出目录
  )
  
  # 保存结果对象
  saveRDS(myGAPIT, file = paste0(output_dir, "/GAPIT_", trait, ".rds"))
}
```

### Q5: 文件名验证和错误处理
**问题现象：** 用户提供错误的文件名时，技能没有主动询问确认

**增强验证逻辑：**
```r
# 增强文件名验证函数
check_and_validate_files <- function(file_paths) {
  validated_files <- list()
  
  for(file_path in file_paths) {
    if(!file.exists(file_path)) {
      cat("⚠️ 警告：文件不存在 -", file_path, "\n")
      
      # 尝试查找相似文件
      dir_path <- dirname(file_path)
      file_name <- basename(file_path)
      similar_files <- list.files(dir_path, pattern = file_name, full.names = TRUE)
      
      if(length(similar_files) > 0) {
        cat("  发现相似文件：\n")
        for(sf in similar_files) {
          cat("  •", basename(sf), "\n")
        }
        cat("  请确认是否使用上述文件？\n")
      } else {
        cat("  未找到相似文件，请检查文件路径和名称。\n")
      }
      
      validated_files[[file_path]] <- FALSE
    } else {
      validated_files[[file_path]] <- TRUE
    }
  }
  
  return(validated_files)
}

# 使用示例
files_to_check <- c("genotype.hmp.txt", "phenotype.csv", "covariate.txt")
validation_result <- check_and_validate_files(files_to_check)

if(all(unlist(validation_result))) {
  cat("✅ 所有文件验证通过，可以开始分析。\n")
} else {
  cat("❌ 部分文件存在问题，请先解决文件路径问题。\n")
}
```

### Q6: 表型文件结构检查
**问题现象：** 假设表型文件第一列总是Taxa/样本ID，没有验证列名结构

**增强检查逻辑：**
```r
# 表型文件结构检查函数
validate_phenotype_structure <- function(pheno_file, expected_id_col = "Taxa") {
  # 读取表型文件
  pheno_data <- read.csv(pheno_file, header = TRUE)
  
  # 检查列名
  col_names <- colnames(pheno_data)
  
  # 查找可能的ID列
  id_col_candidates <- c("Taxa", "SampleID", "ID", "Accession", "Line")
  found_id_col <- NULL
  
  for(candidate in id_col_candidates) {
    if(candidate %in% col_names) {
      found_id_col <- candidate
      break
    }
  }
  
  # 如果没有找到标准ID列名，使用第一列
  if(is.null(found_id_col)) {
    cat("⚠️ 警告：未找到标准ID列名（Taxa/SampleID/ID等）\n")
    cat("  当前列名：", paste(col_names, collapse = ", "), "\n")
    cat("  将使用第一列作为样本ID：", col_names[1], "\n")
    found_id_col <- col_names[1]
  }
  
  # 计算性状数量
  trait_cols <- setdiff(col_names, found_id_col)
  trait_count <- length(trait_cols)
  
  # 返回检查结果
  return(list(
    id_column = found_id_col,
    trait_count = trait_count,
    trait_names = trait_cols,
    all_columns = col_names,
    data_dim = dim(pheno_data),
    validation_passed = TRUE
  ))
}

# 使用示例
pheno_check <- validate_phenotype_structure("phenotype.csv")
cat("表型文件检查结果：\n")
cat("• ID列：", pheno_check$id_column, "\n")
cat("• 性状数量：", pheno_check$trait_count, "\n")
cat("• 性状名称：", paste(pheno_check$trait_names, collapse = ", "), "\n")
```

### Q7: GAPIT输出文件命名规则和结果整合
**问题现象：** 用户需要理解GAPIT输出文件的命名规则，以及如何整合多模型、多性状的分析结果

#### 1. 命名规则详解
**基础命名结构：**
```
GAPIT.[模块].[文件类型].[模型].[性状]([版本]).扩展名
```

**版本标识含义：**
- **(Kansas)**: 逐步回归模型结果 - 零星单个显著位点，像堪萨斯州曼哈顿小镇的天空
- **(NYC)**: 传统GWAS结果 - 连续显著信号区域，像纽约曼哈顿的高楼大厦

**历史背景：**
曼哈顿图命名源自第一位研究者看到连续显著信号联想到纽约曼哈顿的高楼大厦。逐步回归模型产生零星结果后，我们将其命名为Kansas版本，象征堪萨斯州曼哈顿小镇的天空。

**推荐关注版本：**
- **主要关注NYC版本**：查看原始连续信号区域
- **保留Kansas版本**：用于逐步回归模型结果，保持与原始BLINK、FarmCPU等方法报道的一致性

#### 2. 文件格式规则
- **图表文件**: 只输出PDF格式（`.pdf`），不输出PNG
- **数据文件**: 只输出CSV格式（`.csv`）
- **性状名称**: 直接使用表型文件中的列名，R会自动过滤特殊符号

#### 3. 多模型分析命名
- 文件名中的模型名称会相应变化
- 例如：`BLINK` → `FarmCPU` → `MLM`

#### 4. 结果整合最佳实践
**使用file.output=FALSE模式：**
```r
# 多模型、多性状分析结果整合示例
library(GAPIT)

# 1. 数据加载
myY <- read.table("mdp_traits.txt", head = TRUE)
myGD <- read.table("mdp_numeric.txt", head = TRUE)
myGM <- read.table("mdp_SNP_information.txt", head = TRUE)

# 2. 设置分析参数
trait_names <- colnames(myY)[-1]  # 排除Taxa列
model_store <- c("GLM", "MLM", "CMLM", "SUPER", "MLMM", "FarmCPU", "BLINK")

# 3. 运行GAPIT分析（不输出文件）
myGAPIT <- GAPIT(
  Y = myY[, c(1, 2)],  # 分析第一个性状
  GD = myGD,
  GM = myGM,
  PCA.total = 3,
  model = model_store,
  file.output = FALSE  # 关键：不自动输出文件
)

# 4. 手动生成需要的输出文件
if(!is.null(myGAPIT$GWAS)) {
  # 提取GWAS结果
  GWAS <- myGAPIT$GWAS
  
  # 生成QQ图
  GAPIT.QQ(P.values = GWAS[,4], name.of.trait = trait_names[1])
  
  # 生成全基因组曼哈顿图
  GAPIT.Manhattan(
    GI.MP = GWAS[,2:4], 
    name.of.trait = trait_names[1],
    DPP = myGAPIT$DPP,
    plot.type = "Genomewise",
    cutOff = 0.01
  )
  
  # 生成染色体级曼哈顿图
  GAPIT.Manhattan(
    GI.MP = GWAS[,2:4],
    GD = myGD[,-1],
    name.of.trait = trait_names[1],
    plot.type = "Chromosomewise",
    cutOff = 0.01
  )
  
  # 保存GWAS结果
  utils::write.table(
    GWAS, 
    paste("GAPIT.Association.GWAS_Results.", trait_names[1], ".csv", sep = ""),
    quote = FALSE, 
    sep = ",", 
    row.names = FALSE,
    col.names = TRUE
  )
}

# 5. 多模型结果整合
if(length(model_store) > 1) {
  # 生成多模型曼哈顿图
  GMM <- GAPIT.Multiple.Manhattan(
    model_store = model_store,
    Y.names = trait_names[1],  # 单个性状
    GM = myGM,
    plot.type = c("w", "h")  # 宽度和高度对比
  )
  
  # 生成综合曼哈顿图
  GMM <- GAPIT.Multiple.Manhattan(
    model_store = model_store,
    Y.names = trait_names[1],
    GM = myGM,
    plot.type = c("s")  # 综合展示
  )
  
  # 生成圆形曼哈顿图
  GAPIT.Circle.Manhattan.Plot(
    band = 1,
    r = 3,
    GMM$multip_mapP,
    plot.type = c("c", "q"),
    signal.line = 1,
    xz = GMM$xz,
    threshold = 0.05
  )
}

# 6. 多性状分析调整
# 对于多性状分析，需要调整Y.names参数
if(length(trait_names) > 1) {
  GMM_multi <- GAPIT.Multiple.Manhattan(
    model_store = model_store,
    Y.names = trait_names,  # 多个性状
    GM = myGM,
    plot.type = c("w", "h")
  )
}
```

#### 5. 版本管理策略
- **目前没有其他版本标识**：Kansas和NYC是唯二的标识
- **未来扩展**：可能需要添加更多标识，需要智能体的帮助来管理和解决
- **向后兼容性**：通过GitHub发布不同版本，用户可根据需求选择

#### 6. 最佳实践建议
1. **初步分析**：使用NYC版本识别候选区域
2. **精细定位**：结合Kansas版本确定独立显著位点
3. **结果管理**：使用file.output=FALSE模式，手动控制输出文件
4. **版本控制**：依赖文件系统创建时间或自定义时间戳

## 模型选择指南

### 1. GLM（广义线性模型）
- **适用场景**：初步筛选、小样本数据
- **特点**：计算快，不考虑群体结构
- **推荐参数**：`model="GLM", PCA.total=3`

### 2. MLM（混合线性模型）
- **适用场景**：中等样本量，有明显群体结构
- **特点**：校正群体结构和亲缘关系
- **推荐参数**：`model="MLM", PCA.total=5`

### 3. CMLM（压缩混合线性模型）
- **适用场景**：大样本数据，计算资源有限
- **特点**：内存优化，计算效率高
- **推荐参数**：`model="CMLM", PCA.total=5`

### 4. SUPER（Settlement of MLM Under Progressively Exclusive Relationship）
- **适用场景**：高密度SNP数据，精细定位
- **特点**：迭代优化，提高检测功效
- **推荐参数**：`model="SUPER", PCA.total=5`

### 5. MLMM（Multiple Locus Mixed Model）
- **适用场景**：多基因控制性状
- **特点**：同时考虑多个显著位点
- **推荐参数**：`model="MLMM", PCA.total=5`

### 6. FarmCPU（Fixed and random model Circulating Probability Unification）
- **适用场景**：复杂性状，计算效率要求高
- **特点**：固定效应和随机效应分离
- **推荐参数**：`model="FarmCPU", PCA.total=5`

### 7. BLINK（Bayesian-information and Linkage-disequilibrium Iteratively Nested Keyway）
- **适用背景**：超高密度数据，精细定位
- **特点**：贝叶斯框架，迭代优化
- **推荐参数**：`model="BLINK", PCA.total=5`

## 质量控制标准

### 基因型数据QC
1. **缺失率**：< 20%
2. **MAF**：> 0.05（除非特殊研究）
3. **哈迪-温伯格平衡**：p > 1e-6
4. **杂合度**：检查异常样本

### Q8: 基因组选择（GS）和GAGBLUP方法详解
**问题现象：** 用户需要进行基因组选择分析，特别是使用GAGBLUP（GWAS Assisted GBLUP）方法，但不确定如何正确设置参数和进行交叉验证

#### 1. 基因组选择（GS）基本概念
**GS定义：** 使用全基因组标记预测个体育种值的方法
**核心思想：** 利用标记效应估计育种值，提高选择准确性

**主要方法：**
- **GBLUP（基因组最佳线性无偏预测）**：基于基因组关系的混合模型方法
- **GAGBLUP（GWAS Assisted GBLUP）**：结合GWAS和GS的混合方法
- **MAS（标记辅助选择）**：仅使用显著标记进行选择

#### 2. GAGBLUP方法原理和优势
**核心原理：**
1. **GWAS筛选**：使用BLINK等模型进行GWAS，识别显著标记
2. **标记分类**：根据GWAS结果将标记分为：
   - 显著标记：作为固定效应
   - 有效应标记：用于构建亲缘关系矩阵
   - 无效应标记：被排除（默认排除pv.cut=0.2，即20%标记）
3. **GBLUP预测**：使用筛选后的标记构建分子亲缘关系矩阵，进行育种值估计

**优势：**
- **提高准确性**：在QTN数目适中时优于MAS和GBLUP
- **稳定性好**：QTN数目多时预测准确性下降较慢，较早到达平稳
- **减少标记冗余**：通过QR分解筛选核心标记
- **结合GWAS信息**：利用GWAS结果指导标记选择

**适用场景：**
- **最佳场景**：QTN数目比较适中时（N=10-15）
- **良好场景**：QTN数目少时（N<10），与MAS相当
- **一般场景**：QTN数目多时（N>20），优于MAS但计算较慢

#### 3. 正确使用方法
**关键要点：** 必须放入全部基因型数据和参考群体表型数据

```r
# GAGBLUP正确使用方法示例
library(GAPIT)

# 1. 数据准备
myY <- read.table("phenotype.txt", head = TRUE)  # 表型数据
myGD <- read.table("genotype_numeric.txt", head = TRUE)  # 全部基因型数据
myGM <- read.table("SNP_information.txt", head = TRUE)  # 标记信息

# 2. 模拟表型（用于测试）
# 按照GAPIT4文献设置：低遗传力，少QTN
mysimulation <- GAPIT.Phenotype.Simulation(
  h2 = 0.25,      # 低遗传力
  NQTN = 5,       # 少QTN
  GD = myGD,
  GM = myGM
)

# 3. 运行GAGBLUP分析
myGAPIT_GAGBLUP <- GAPIT(
  Y = myY[, c(1, 2)],  # 仅参考群体表型（有表型的个体）
  GD = myGD,           # 全部基因型数据（包含参考和预测群体）
  GM = myGM,
  PCA.total = 3,
  model = c("BLINK"),  # 使用BLINK模型进行GWAS
  buspred = TRUE,      # 在GWAS后进行预测
  lmpred = c(FALSE),   # FALSE表示使用GAGBLUP，TRUE表示使用MAS
  file.output = TRUE,
  Multiple_analysis = FALSE
)
```

#### 4. RefInf列的含义和用途
**输出文件：** `GAPIT.Association.Prediction_results.BLINK.Sim.ABLUP.csv`

**RefInf列值含义：**
- **1**：个体属于参考群体（有表型数据）
- **1.5或2**：个体属于预测群体（无表型数据，需要预测）

**使用示例：**
```r
# 读取预测结果
pred_results <- read.csv("GAPIT.Association.Prediction_results.BLINK.Sim.ABLUP.csv")

# 分离参考群体和预测群体
reference_group <- pred_results[pred_results$RefInf == 1, ]
prediction_group <- pred_results[pred_results$RefInf %in% c(1.5, 2), ]

# 计算预测准确性（仅参考群体）
correlation <- cor(reference_group$Simulated_Trait, reference_group$Predicted_Value)
cat("预测准确性：", correlation, "\n")
```

#### 5. 交叉验证最佳实践
**关键要求：** 至少20次重复交叉验证

```r
# 20次重复交叉验证示例
n_repeats <- 20
cv_results <- data.frame(
  repeat_id = integer(),
  method = character(),
  correlation = numeric(),
  stringsAsFactors = FALSE
)

# 准备分析数据
Y_analysis <- myY[!is.na(myY$Simulated_Trait), c(1, 2)]

for (rep in 1:n_repeats) {
  set.seed(198521 + rep)
  
  # 随机划分训练集和验证集（70%训练，30%验证）
  n_train <- round(0.7 * nrow(Y_analysis))
  train_indices <- sample(1:nrow(Y_analysis), size = n_train)
  
  Y_train <- Y_analysis[train_indices, ]
  Y_valid <- Y_analysis[-train_indices, ]
  
  # 运行GAGBLUP分析
  myGAPIT_rep <- GAPIT(
    Y = Y_train,
    GD = myGD,
    GM = myGM,
    PCA.total = 3,
    model = c("BLINK"),
    buspred = TRUE,
    lmpred = c(FALSE),
    file.output = FALSE,  # 不输出文件，避免覆盖
    Multiple_analysis = FALSE
  )
  
  # 提取预测结果
  if (!is.null(myGAPIT_rep$Pred)) {
    pred_values <- myGAPIT_rep$Pred$Predicted_Value
    true_values <- Y_valid$Simulated_Trait
    
    # 计算相关性
    cor_value <- cor(pred_values, true_values, use = "complete.obs")
    
    # 保存结果
    cv_results <- rbind(cv_results, data.frame(
      repeat_id = rep,
      method = "GAGBLUP",
      correlation = cor_value
    ))
  }
}

# 计算统计指标
mean_cor <- mean(cv_results$correlation)
sd_cor <- sd(cv_results$correlation)
cat("GAGBLUP平均预测准确性：", round(mean_cor, 4), "±", round(sd_cor, 4), "\n")
```

#### 6. 与GBLUP和MAS的对比分析
**典型结果模式（基于GAPIT4文献）：**

| 条件 | GAGBLUP表现 | MAS表现 | GBLUP表现 | 原因分析 |
|------|------------|----------|-----------|----------|
| 少QTN（N=5） | 大幅领先GBLUP | 领先GBLUP | 较低 | GWAS能准确识别少数显著标记 |
| 适中QTN（N=10-15） | **最优** | 次优 | 较低 | GAGBLUP结合了GWAS筛选和基因组关系优势 |
| 多QTN（N=20+） | 下降但较早到达平稳 | 快速下降 | 相对稳定 | 标记效应分散，筛选效果减弱 |
| 低遗传力（h2=0.25） | 优势更明显 | 优势明显 | 较低 | GWAS筛选提高了标记信息含量 |
| 高遗传力（h2=0.8） | 优势减小 | 优势减小 | 相对较高 | GBLUP本身已足够准确 |

**关键发现：**
1. **QTN数目是关键因素**：只要QTN数目少，GAGBLUP和MAS都领先于GBLUP
2. **QTN数目多时**：MAS和GAGBLUP预测准确率都会下降，但MAS下降更快，GAGBLUP下降较慢且更早到达平稳
3. **最佳应用场景**：QTN数目比较适中时，GAGBLUP优于MAS和GBLUP
4. **计算效率**：MAS计算最快，GAGBLUP较慢但预测准确性更稳定

**统计检验示例：**
```r
# 假设已有GBLUP和GAGBLUP的交叉验证结果
gagblup_cor <- cv_results_gagblup$correlation
gblup_cor <- cv_results_gblup$correlation

# 配对t检验
t_test_result <- t.test(gagblup_cor, gblup_cor, paired = TRUE)
cat("配对t检验结果：\n")
cat("t值：", t_test_result$statistic, "\n")
cat("p值：", t_test_result$p.value, "\n")

# 效应量计算
mean_diff <- mean(gagblup_cor) - mean(gblup_cor)
sd_diff <- sd(gagblup_cor - gblup_cor)
cohens_d <- mean_diff / sd_diff
cat("Cohen's d效应量：", round(cohens_d, 4), "\n")
```

#### 7. 参数设置指南
**关键参数说明：**

| 参数 | 类型 | 默认值 | 作用 |
|------|------|--------|------|
| `buspred` | 逻辑值 | FALSE | 是否在GWAS后进行预测 |
| `lmpred` | 逻辑向量 | c(FALSE) | FALSE=GAGBLUP, TRUE=MAS |
| `pv.cut` | 数值 | 0.2 | 排除标记的比例阈值 |
| `h2` | 数值 | 0.5 | 模拟表型的遗传力 |
| `NQTN` | 整数 | 10 | 模拟表型的QTN数量 |

**推荐设置：**
```r
# 测试GAGBLUP优势的最佳设置
myGAPIT <- GAPIT(
  Y = myY,
  GD = myGD,
  GM = myGM,
  PCA.total = 3,
  model = c("BLINK"),
  buspred = TRUE,      # 启用预测
  lmpred = c(FALSE),   # 使用GAGBLUP
  pv.cut = 0.2,        # 排除20%标记
  file.output = TRUE
)
```

#### 8. 实际应用建议
1. **数据准备**：
   - 确保基因型数据包含所有个体（参考+预测）
   - 表型数据仅包含参考群体
   - 检查缺失值和数据质量

2. **QTN数目评估**：
   - **少QTN（N<10）**：GAGBLUP和MAS都表现良好，MAS计算更快
   - **适中QTN（N=10-15）**：GAGBLUP表现最优，推荐使用
   - **多QTN（N>20）**：GAGBLUP优于MAS但计算较慢，GBLUP相对稳定

3. **分析流程**：
   - 先进行GWAS分析，评估QTN数目和遗传力
   - 根据QTN数目选择合适方法：
     - 少QTN：可考虑MAS（计算快）
     - 适中QTN：推荐GAGBLUP（准确性高）
     - 多QTN：GAGBLUP或GBLUP（稳定性好）
   - 运行选定方法，获取预测结果
   - 进行20次重复交叉验证，评估准确性
   - 与GBLUP和MAS对比，验证方法优势

4. **结果解释**：
   - 关注RefInf列，正确识别群体类型
   - 计算预测准确性时，仅使用参考群体
   - 结合QTN数目和遗传力解释结果模式
   - 注意不同条件下方法的相对表现

5. **优化策略**：
   - 调整pv.cut参数，优化标记筛选
   - 尝试不同GWAS模型（FarmCPU vs BLINK）
   - 考虑群体结构和亲缘关系校正
   - 根据计算资源选择方法：MAS最快，GAGBLUP较慢但更稳定

**参考文献：**
- GAPIT4文献：`msag107.pdf`（位于`/Users/Jiabo/Documents/trae_projects/GAPIT-Agent/data/gapit-resources/documentation/publications/`）
- 关键发现：在低遗传力（h2=0.25）、少QTN（N=5）条件下，GAGBLUP大幅领先于GBLUP

### 表型数据QC
1. **缺失值**：< 10%
2. **异常值**：±3标准差外检查
3. **正态性**：必要时进行转换
4. **批次效应**：检查实验批次影响

## 结果解读标准

### 曼哈顿图解读
1. **显著阈值**：通常使用Bonferroni校正（p < 0.05/n）
2. **建议阈值**：p < 1e-5作为初步筛选标准
3. **区域聚集**：检查是否有多个显著SNP聚集

### QQ图解读
1. **λ值**：理想情况λ ≈ 1.0
2. **膨胀情况**：λ > 1.05可能表示群体结构未充分校正
3. **收缩情况**：λ < 0.95可能表示过度校正

## 最佳实践建议

### 分析流程
1. **数据准备**：格式转换、质量控制
2. **模型选择**：根据数据特点选择合适模型
3. **参数优化**：尝试不同PCA数量、迭代次数
4. **结果验证**：使用不同模型交叉验证

### 性能优化
1. **内存管理**：分批处理大数据
2. **并行计算**：利用多核CPU加速
3. **磁盘空间**：确保足够存储空间
4. **日志记录**：保存分析日志便于调试

## 版本兼容性

### 支持版本
- **GAPIT版本**：3.0及以上
- **R版本**：3.6.0及以上
- **操作系统**：Windows、macOS、Linux

### 已知问题
1. **Windows路径**：避免中文和特殊字符
2. **macOS权限**：可能需要终端权限设置
3. **Linux依赖**：确保编译工具链完整

## 故障排除

### 常见错误及解决
1. **"object not found"**：检查变量名和数据加载
2. **"cannot allocate vector"**：增加内存或减少数据
3. **"subscript out of bounds"**：检查数据维度匹配
4. **"convergence failed"**：调整模型参数或简化模型

## 扩展功能

### 高级分析
1. **基因集分析**：富集分析、通路分析
2. **多性状分析**：多变量GWAS、相关性分析
3. **上位性分析**：基因-基因互作
4. **环境互作**：基因-环境互作分析

### 数据整合
1. **多组学整合**：基因组、转录组、表观组
2. **公共数据**：整合GWAS Catalog、dbSNP等
3. **功能注释**：使用ANNOVAR、VEP等工具

## 多性状分析最佳实践

### 1. 文件组织策略
**问题**：多性状分析时，GAPIT输出文件会相互覆盖
**解决方案**：
```r
# 为每个性状创建独立目录
for(trait in trait_names) {
  output_dir <- paste0("GAPIT_Output_", trait)
  dir.create(output_dir, showWarnings = FALSE)
  
  myGAPIT <- GAPIT(
    Y = phenotype_data[, c("Taxa", trait)],
    G = genotype_data,
    file.output = TRUE,
    file.path = output_dir  # 关键：指定独立输出目录
  )
}
```

### 2. 分析效率优化
**特点**：GAPIT在多性状循环分析时会优化计算
- **第一次分析**：生成完整的基因型数据处理、亲缘关系矩阵、PCA结果
- **后续分析**：复用已有结果，只计算性状-specific的关联分析
- **优势**：大幅减少计算时间，特别是对于大型数据集

### 3. 结果文件管理
**需要特别注意的文件**：
1. **会覆盖的文件**：
   - `GWAS.Results.csv`（主要结果）
   - `GAPIT.Manhattan.png`（曼哈顿图）
   - `GAPIT.QQ.png`（QQ图）
   - `GAPIT.PCA.png`（PCA图）

2. **只生成一次的文件**：
   - 基因型数据处理中间文件
   - 亲缘关系矩阵文件
   - PCA计算结果

### 4. 完整的多性状分析示例
```r
# 多性状分析完整示例
library(GAPIT)

# 1. 数据加载
genotype_data <- read.table("genotype.hmp.txt", header = TRUE, sep = "\t")
phenotype_data <- read.csv("phenotype.csv", header = TRUE)

# 2. 表型文件结构检查
validate_phenotype_structure <- function(pheno_data) {
  id_col_candidates <- c("Taxa", "SampleID", "ID", "Accession", "Line")
  
  for(col in id_col_candidates) {
    if(col %in% colnames(pheno_data)) {
      return(list(id_col = col, trait_cols = setdiff(colnames(pheno_data), col)))
    }
  }
  
  # 默认使用第一列
  return(list(id_col = colnames(pheno_data)[1], 
              trait_cols = colnames(pheno_data)[-1]))
}

# 3. 获取性状信息
pheno_info <- validate_phenotype_structure(phenotype_data)
trait_names <- pheno_info$trait_cols

cat("📊 分析计划：\n")
cat("• 样本ID列：", pheno_info$id_col, "\n")
cat("• 性状数量：", length(trait_names), "\n")
cat("• 性状列表：", paste(trait_names, collapse = ", "), "\n")

# 4. 多性状循环分析
results_summary <- data.frame()

for(i in 1:length(trait_names)) {
  trait <- trait_names[i]
  
  cat("\n🔬 正在分析性状：", trait, "(", i, "/", length(trait_names), ")\n")
  
  # 创建独立输出目录
  output_dir <- paste0("GAPIT_Output_", trait)
  dir.create(output_dir, showWarnings = FALSE)
  
  # 准备表型数据
  Y_data <- phenotype_data[, c(pheno_info$id_col, trait)]
  colnames(Y_data) <- c("Taxa", "trait")
  
  # 运行GAPIT
  myGAPIT <- GAPIT(
    Y = Y_data,
    G = genotype_data,
    PCA.total = 5,
    model = "MLM",
    file.output = TRUE,
    file.path = output_dir,
    Multiple_analysis = TRUE  # 启用多分析模式
  )
  
  # 记录结果摘要
  if(!is.null(myGAPIT$GWAS)) {
    sig_snps <- myGAPIT$GWAS[myGAPIT$GWAS$P.value < 1e-5, ]
    results_summary <- rbind(results_summary, data.frame(
      trait = trait,
      total_snps = nrow(myGAPIT$GWAS),
      significant_snps = nrow(sig_snps),
      min_p_value = min(myGAPIT$GWAS$P.value, na.rm = TRUE),
      lambda = ifelse(!is.null(myGAPIT$P3D$lambda), myGAPIT$P3D$lambda, NA)
    ))
  }
  
  cat("✅ 性状", trait, "分析完成，结果保存在：", output_dir, "\n")
}

# 5. 生成汇总报告
if(nrow(results_summary) > 0) {
  write.csv(results_summary, "GAPIT_MultiTrait_Summary.csv", row.names = FALSE)
  cat("\n📈 多性状分析汇总报告已生成：GAPIT_MultiTrait_Summary.csv\n")
  print(results_summary)
}
```

### 5. 常见问题解答

**Q: 为什么后续性状分析更快？**
A: GAPIT会缓存基因型数据处理结果，后续分析只需计算性状-specific的统计量。

**Q: 如何确保每个性状的结果不被覆盖？**
A: 使用`file.path`参数为每个性状指定独立输出目录。

**Q: 如果只想分析部分性状怎么办？**
A: 可以修改循环范围，例如`for(i in 1:2)`只分析前两个性状。

**Q: 如何批量处理大量性状？**
A: 建议分批处理，每批10-20个性状，避免内存不足。

## 基于用户反馈的重要更新

### Q9: 详细的GAPIT参数说明表
**问题现象：** 用户反映GAPIT参数说明不够详细，特别是`lmpred`参数含义不明确，缺少系统性的参数说明文档

#### 1. 核心参数说明表

| 参数 | 类型 | 默认值 | 作用 | 推荐设置 | 适用场景 |
|------|------|--------|------|----------|----------|
| `buspred` | 逻辑值 | FALSE | 是否在GWAS后进行预测 | TRUE | 需要进行基因组选择预测时 |
| `lmpred` | 逻辑向量 | c(FALSE) | FALSE=使用GAGBLUP, TRUE=使用MAS | c(FALSE) | GAGBLUP方法优于MAS时 |
| `pv.cut` | 数值 | 0.2 | 排除标记的比例阈值 | 0.2 | 默认设置，可根据数据调整 |
| `h2` | 数值 | 0.5 | 模拟表型的遗传力 | 0.25-0.8 | 根据实际遗传力设置 |
| `NQTN` | 整数 | 10 | 模拟表型的QTN数量 | 5-20 | 根据性状遗传结构设置 |
| `PCA.total` | 整数 | 3 | PCA主成分数量 | 3-5 | 校正群体结构 |
| `model` | 字符向量 | "MLM" | 关联分析模型 | c("BLINK") | 根据数据特点选择 |
| `file.output` | 逻辑值 | TRUE | 是否输出结果文件 | TRUE | 需要保存结果时 |
| `Multiple_analysis` | 逻辑值 | FALSE | 是否启用多分析模式 | TRUE | 多性状分析时 |

#### 2. 关键参数详细解释

**`lmpred`参数：**
- **FALSE（默认）**：使用GAGBLUP（GWAS Assisted GBLUP）方法
  - 结合GWAS筛选和基因组关系
  - 在QTN数目适中时表现最优
  - 计算较慢但稳定性好
- **TRUE**：使用MAS（标记辅助选择）方法
  - 仅使用显著标记进行选择
  - 在QTN数目少时表现良好
  - 计算最快但稳定性较差

**`buspred`参数：**
- **FALSE（默认）**：仅进行GWAS分析，不进行预测
- **TRUE**：在GWAS后进行基因组选择预测
  - 需要提供全部基因型数据
  - 表型数据仅包含参考群体
  - 输出预测群体的预测结果

#### 3. 模型选择决策树

```
开始
├── 样本量 < 100?
│   ├── 是 → 使用GLM模型
│   └── 否 → 继续
├── 有明显群体结构？
│   ├── 是 → 使用MLM模型（PCA.total=5）
│   └── 否 → 继续
├── 数据量很大，计算资源有限？
│   ├── 是 → 使用CMLM模型
│   └── 否 → 继续
├── 需要精细定位？
│   ├── 是 → 使用SUPER模型
│   └── 否 → 继续
├── 多基因控制性状？
│   ├── 是 → 使用MLMM模型
│   └── 否 → 继续
├── 计算效率要求高？
│   ├── 是 → 使用FarmCPU模型
│   └── 否 → 继续
└── 默认 → 使用BLINK模型（推荐）
```

### Q10: 交叉验证最佳实践和结果解读指南
**问题现象：** 用户反映交叉验证设置不合理，结果解读指导不足，不知道如何评估结果可靠性

#### 1. 交叉验证标准设置

**推荐设置：**
- **重复次数**：至少20次
- **折数**：5折交叉验证
- **训练集比例**：70%
- **验证集比例**：30%

**代码示例：**
```r
# 20次重复5折交叉验证标准模板
library(GAPIT)
library(caret)

# 数据准备
myY <- read.table("phenotype.txt", head = TRUE)
myGD <- read.table("genotype_numeric.txt", head = TRUE)
myGM <- read.table("SNP_information.txt", head = TRUE)

# 交叉验证设置
n_repeats <- 20
cv_results <- data.frame()

for (rep in 1:n_repeats) {
  set.seed(198521 + rep)
  
  # 创建5折交叉验证
  folds <- createFolds(1:nrow(myY), k = 5, returnTrain = TRUE)
  
  for (fold in 1:5) {
    train_indices <- folds[[fold]]
    valid_indices <- setdiff(1:nrow(myY), train_indices)
    
    Y_train <- myY[train_indices, ]
    Y_valid <- myY[valid_indices, ]
    
    # 运行GAPIT分析
    myGAPIT <- GAPIT(
      Y = Y_train,
      GD = myGD,
      GM = myGM,
      PCA.total = 3,
      model = c("BLINK"),
      buspred = TRUE,
      lmpred = c(FALSE),
      file.output = FALSE,
      Multiple_analysis = FALSE
    )
    
    # 计算预测准确性
    if (!is.null(myGAPIT$Pred)) {
      pred_values <- myGAPIT$Pred$Predicted_Value
      true_values <- Y_valid$Simulated_Trait
      
      cor_value <- cor(pred_values, true_values, use = "complete.obs")
      
      cv_results <- rbind(cv_results, data.frame(
        repeat_id = rep,
        fold_id = fold,
        method = "GAGBLUP",
        correlation = cor_value
      ))
    }
  }
}

# 计算统计指标
mean_cor <- mean(cv_results$correlation)
sd_cor <- sd(cv_results$correlation)
cat("平均预测准确性：", round(mean_cor, 4), "±", round(sd_cor, 4), "\n")
cat("95%置信区间：", round(mean_cor - 1.96*sd_cor/sqrt(nrow(cv_results)), 4), 
    "to", round(mean_cor + 1.96*sd_cor/sqrt(nrow(cv_results)), 4), "\n")
```

#### 2. 结果解读标准流程

**步骤1：检查预测准确性范围**
- **优秀**：> 0.7
- **良好**：0.5-0.7
- **一般**：0.3-0.5
- **较差**：< 0.3

**步骤2：评估结果稳定性**
```r
# 稳定性评估
cv_summary <- cv_results %>%
  group_by(method) %>%
  summarise(
    mean_cor = mean(correlation),
    sd_cor = sd(correlation),
    cv = sd_cor / mean_cor * 100,  # 变异系数
    min_cor = min(correlation),
    max_cor = max(correlation),
    range = max_cor - min_cor
  )

# 判断标准
# 变异系数 < 20%：稳定性好
# 变异系数 20%-40%：稳定性一般
# 变异系数 > 40%：稳定性差
```

**步骤3：模型比较和选择**
```r
# 多模型比较
model_comparison <- function(gagblup_results, gblup_results, mas_results) {
  # 配对t检验
  t_test_gagblup_vs_gblup <- t.test(gagblup_results, gblup_results, paired = TRUE)
  t_test_gagblup_vs_mas <- t.test(gagblup_results, mas_results, paired = TRUE)
  
  # 效应量计算
  cohens_d <- function(x, y) {
    mean_diff <- mean(x) - mean(y)
    sd_diff <- sd(x - y)
    mean_diff / sd_diff
  }
  
  return(list(
    gagblup_vs_gblup = list(
      p_value = t_test_gagblup_vs_gblup$p.value,
      effect_size = cohens_d(gagblup_results, gblup_results)
    ),
    gagblup_vs_mas = list(
      p_value = t_test_gagblup_vs_mas$p.value,
      effect_size = cohens_d(gagblup_results, mas_results)
    )
  ))
}
```

#### 3. 常见问题解答

**Q: GAGBLUP预测结果明显低于gBLUP和BayesB，是什么原因？**
A: 可能原因：
1. **QTN数目多**：GAGBLUP在QTN数目多时预测准确性会下降
2. **遗传力低**：低遗传力条件下所有方法表现都会下降
3. **参数设置不当**：检查`pv.cut`、`h2`、`NQTN`等参数
4. **数据质量问题**：检查基因型和表型数据质量

**Q: 如何判断预测结果是否合理？**
A: 检查以下指标：
1. **预测准确性**：应在合理范围内（通常0.3-0.8）
2. **结果稳定性**：变异系数应小于40%
3. **模型一致性**：不同模型结果应有一定一致性
4. **生物学合理性**：结果应符合生物学常识

**Q: 推荐的交叉验证设置是什么？**
A: **至少20次重复5折交叉验证**，原因：
1. **稳定性**：多次重复减少随机波动影响
2. **可靠性**：5折平衡计算效率和结果可靠性
3. **可比性**：标准设置便于不同研究比较

### Q11: 环境锁定和文件校验最佳实践
**问题现象：** 用户反映环境锁定慢、风险提示弱、主动确认少

#### 1. 环境锁定标准流程

```r
# 环境锁定标准模板
lock_environment <- function() {
  # 1. 检测操作系统
  os_type <- .Platform$OS.type
  if (os_type == "unix") {
    # 进一步检测具体Linux发行版或macOS
    if (Sys.info()["sysname"] == "Darwin") {
      current_os <- "macOS"
    } else {
      current_os <- "Linux"
    }
  } else {
    current_os <- "Windows"
  }
  
  # 2. 检测R环境
  r_version <- R.version$version.string
  r_platform <- R.version$platform
  
  # 3. 检测GAPIT安装状态
  gapit_installed <- "GAPIT" %in% installed.packages()[, "Package"]
  
  # 4. 检测工作目录和文件权限
  current_wd <- getwd()
  can_write <- file.access(current_wd, 2) == 0
  
  return(list(
    os = current_os,
    r_version = r_version,
    r_platform = r_platform,
    gapit_installed = gapit_installed,
    working_directory = current_wd,
    write_permission = can_write
  ))
}

# 使用示例
env_info <- lock_environment()
cat("🔒 环境锁定信息：\n")
cat("• 操作系统：", env_info$os, "\n")
cat("• R版本：", env_info$r_version, "\n")
cat("• GAPIT安装状态：", ifelse(env_info$gapit_installed, "已安装", "未安装"), "\n")
cat("• 工作目录：", env_info$working_directory, "\n")
cat("• 写入权限：", ifelse(env_info$write_permission, "有", "无"), "\n")
```

#### 2. 文件校验前置检查

```r
# 文件校验标准模板
validate_input_files <- function(file_paths, expected_extensions = NULL) {
  validation_results <- list()
  
  for (file_path in file_paths) {
    # 1. 检查文件是否存在
    if (!file.exists(file_path)) {
      cat("⚠️ 警告：文件不存在 -", file_path, "\n")
      
      # 尝试查找相似文件
      dir_path <- dirname(file_path)
      file_name <- basename(file_path)
      
      # 提取文件名主体（不含扩展名）
      file_base <- tools::file_path_sans_ext(file_name)
      file_ext <- tools::file_ext(file_name)
      
      # 查找相似文件
      all_files <- list.files(dir_path, full.names = TRUE)
      similar_files <- all_files[grepl(file_base, basename(all_files), ignore.case = TRUE)]
      
      if (length(similar_files) > 0) {
        cat("  发现相似文件：\n")
        for (sf in similar_files) {
          cat("  •", basename(sf), "\n")
        }
        cat("  请确认是否使用上述文件？\n")
      }
      
      validation_results[[file_path]] <- list(
        exists = FALSE,
        similar_files = similar_files
      )
    } else {
      # 2. 检查文件可读性
      can_read <- file.access(file_path, 4) == 0
      
      # 3. 检查文件大小
      file_size <- file.info(file_path)$size
      
      # 4. 检查文件扩展名（如果指定）
      ext_valid <- TRUE
      if (!is.null(expected_extensions)) {
        current_ext <- tools::file_ext(file_path)
        ext_valid <- tolower(current_ext) %in% tolower(expected_extensions)
      }
      
      validation_results[[file_path]] <- list(
        exists = TRUE,
        readable = can_read,
        size = file_size,
        extension_valid = ext_valid,
        full_path = normalizePath(file_path)
      )
    }
  }
  
  return(validation_results)
}

# 使用示例
files_to_check <- c(
  "phenotype.csv",
  "genotype.hmp.txt", 
  "SNP_information.txt"
)

validation <- validate_input_files(files_to_check, 
                                   expected_extensions = c("csv", "txt"))

if (all(sapply(validation, function(x) x$exists))) {
  cat("✅ 所有文件验证通过\n")
} else {
  cat("❌ 部分文件存在问题，请检查\n")
  print(validation)
}
```

#### 3. ID列自动识别

```r
# ID列自动识别标准模板
auto_detect_id_column <- function(pheno_data) {
  # 常见ID列名模式
  id_patterns <- c(
    "^taxa$", "^sample$", "^id$", "^accession$", "^line$",
    "^individual$", "^plant$", "^animal$", "^patient$"
  )
  
  col_names <- tolower(colnames(pheno_data))
  
  for (pattern in id_patterns) {
    matches <- grep(pattern, col_names)
    if (length(matches) > 0) {
      return(list(
        id_column = colnames(pheno_data)[matches[1]],
        column_index = matches[1],
        detection_method = "pattern_match"
      ))
    }
  }
  
  # 如果未找到匹配模式，使用启发式方法
  # 1. 检查第一列是否包含唯一标识符
  first_col <- pheno_data[, 1]
  if (length(unique(first_col)) == nrow(pheno_data)) {
    return(list(
      id_column = colnames(pheno_data)[1],
      column_index = 1,
      detection_method = "heuristic_unique"
    ))
  }
  
  # 2. 默认使用第一列
  cat("⚠️ 警告：未自动识别到ID列，将使用第一列作为样本ID\n")
  return(list(
    id_column = colnames(pheno_data)[1],
    column_index = 1,
    detection_method = "default_first"
  ))
}

# 使用示例
pheno_data <- read.csv("phenotype.csv", header = TRUE)
id_info <- auto_detect_id_column(pheno_data)

cat("📋 ID列识别结果：\n")
cat("• 识别方法：", id_info$detection_method, "\n")
cat("• ID列名：", id_info$id_column, "\n")
cat("• 列索引：", id_info$column_index, "\n")

# 提取性状列
trait_cols <- setdiff(colnames(pheno_data), id_info$id_column)
cat("• 性状列：", paste(trait_cols, collapse = ", "), "\n")
```

#### 4. 最佳实践总结

1. **环境锁定前置**：
   - 在分析开始前锁定操作系统环境
   - 检测R版本和GAPIT安装状态
   - 检查文件读写权限

2. **文件校验主动**：
   - 主动检查文件是否存在
   - 提供相似文件建议
   - 验证文件格式和扩展名

3. **ID列自动识别**：
   - 自动检测样本ID列
   - 提供多种识别方法
   - 给出明确的识别结果

4. **风险提示强化**：
   - 明确提示潜在问题
   - 提供解决方案建议
   - 记录校验过程和结果

### Q12: 基于用户反馈的代码生成优化
**问题现象：** 用户反馈代码生成在某些场景下需要更明确的文件名验证和参数说明

#### 1. 文件名验证和主动确认

**问题：** 用户提供的文件名可能有笔误，需要更主动地询问确认

**解决方案：**
```r
# 文件名验证和主动确认标准模板
validate_and_confirm_files <- function(file_paths, working_dir = getwd()) {
  cat("📁 文件验证开始...\n")
  
  validation_results <- list()
  
  for (file_path in file_paths) {
    full_path <- file.path(working_dir, file_path)
    
    if (!file.exists(full_path)) {
      cat("❌ 文件不存在：", file_path, "\n")
      
      # 查找相似文件
      all_files <- list.files(working_dir, full.names = FALSE)
      similar_files <- all_files[agrepl(file_path, all_files, max.distance = 0.3)]
      
      if (length(similar_files) > 0) {
        cat("  发现相似文件：\n")
        for (i in 1:min(3, length(similar_files))) {
          cat("  ", i, ". ", similar_files[i], "\n")
        }
        cat("  是否使用上述文件？请输入文件编号或输入'n'继续：")
        user_input <- readline()
        
        if (user_input != "n" && user_input %in% as.character(1:length(similar_files))) {
          selected_file <- similar_files[as.numeric(user_input)]
          cat("✅ 已选择文件：", selected_file, "\n")
          validation_results[[file_path]] <- list(
            original = file_path,
            selected = selected_file,
            status = "corrected"
          )
        } else {
          validation_results[[file_path]] <- list(
            original = file_path,
            status = "missing"
          )
        }
      } else {
        validation_results[[file_path]] <- list(
          original = file_path,
          status = "missing_no_similar"
        )
      }
    } else {
      cat("✅ 文件存在：", file_path, "\n")
      validation_results[[file_path]] <- list(
        original = file_path,
        status = "exists"
      )
    }
  }
  
  return(validation_results)
}

# 使用示例
files_to_check <- c("phenotype.csv", "genotype.hmp.txt", "SNP_info.txt")
validation <- validate_and_confirm_files(files_to_check)

# 根据验证结果生成代码
if (all(sapply(validation, function(x) x$status == "exists"))) {
  cat("✅ 所有文件验证通过，生成分析代码...\n")
  # 生成标准分析代码
} else {
  cat("⚠️ 部分文件存在问题，请确认后再生成代码\n")
}
```

#### 2. file.output参数明确说明

**问题：** 用户不清楚file.output=TRUE的重要性，导致没有保存结果文件

**解决方案：**
```r
# 循环跑GWAS时明确说明file.output参数
generate_gwas_loop_code <- function(pheno_file, geno_file, snp_file, 
                                    output_dir = "GWAS_Results",
                                    file_output = TRUE) {
  
  code <- paste0(
    "# GAPIT多性状循环分析代码\n",
    "# 注意：file.output参数控制是否生成结果文件\n",
    "# 设置为TRUE时，会生成PDF图和CSV结果文件\n",
    "# 设置为FALSE时，只返回R对象，不保存文件\n",
    "\n",
    "library(GAPIT)\n",
    "\n",
    "# 1. 读取数据\n",
    "myY <- read.table(\"", pheno_file, "\", header = TRUE)\n",
    "myGD <- read.table(\"", geno_file, "\", header = TRUE)\n",
    "myGM <- read.table(\"", snp_file, "\", header = TRUE)\n",
    "\n",
    "# 2. 自动识别ID列和性状列\n",
    "id_info <- auto_detect_id_column(myY)\n",
    "cat(\"📋 表型文件结构：\\n\")\n",
    "cat(\"• ID列：\", id_info$id_column, \"（第\", id_info$column_index, \"列）\\n\")\n",
    "trait_cols <- setdiff(colnames(myY), id_info$id_column)\n",
    "cat(\"• 性状列：\", paste(trait_cols, collapse = \", \"), \"\\n\")\n",
    "\n",
    "# 3. 创建输出目录\n",
    "if (!dir.exists(\"", output_dir, "\")) {\n",
    "  dir.create(\"", output_dir, "\")\n",
    "}\n",
    "\n",
    "# 4. 循环分析每个性状\n",
    "all_results <- list()\n",
    "\n",
    "for (trait in trait_cols) {\n",
    "  cat(\"\\n🔍 正在分析性状：\", trait, \"\\n\")\n",
    "  \n",
    "  # 提取当前性状数据\n",
    "  Y_current <- myY[, c(id_info$id_column, trait)]\n",
    "  colnames(Y_current) <- c(\"Taxa\", trait)\n",
    "  \n",
    "  # 运行GAPIT\n",
    "  myGAPIT <- GAPIT(\n",
    "    Y = Y_current,\n",
    "    GD = myGD,\n",
    "    GM = myGM,\n",
    "    PCA.total = 3,\n",
    "    model = c(\"BLINK\"),\n",
    "    file.output = ", ifelse(file_output, "TRUE", "FALSE"), ",  # 重要参数：控制文件输出\n",
    "    Multiple_analysis = FALSE\n",
    "  )\n",
    "  \n",
    "  # 保存结果\n",
    "  all_results[[trait]] <- myGAPIT$GWAS\n",
    "  \n",
    "  # 如果file.output=TRUE，文件会自动保存到当前目录\n",
    "  # 如果file.output=FALSE，需要手动保存结果\n",
    "  if (!", ifelse(file_output, "TRUE", "FALSE"), ") {\n",
    "    write.csv(myGAPIT$GWAS, \n",
    "              file = file.path(\"", output_dir, "\", \n",
    "                              paste0(\"GWAS_\", trait, \".csv\")),\n",
    "              row.names = FALSE)\n",
    "  }\n",
    "}\n",
    "\n",
    "cat(\"\\n✅ 分析完成！\\n\")\n",
    "if (", ifelse(file_output, "TRUE", "FALSE"), ") {\n",
    "  cat(\"• 结果文件已自动保存到当前目录\\n\")\n",
    "} else {\n",
    "  cat(\"• 结果文件已手动保存到：\", \"", output_dir, "\"\\n\")\n",
    "}\n"
  )
  
  return(code)
}

# 使用示例
pheno_file <- "my_phenotype.txt"
geno_file <- "my_genotype.hmp.txt"
snp_file <- "my_SNP_info.txt"

analysis_code <- generate_gwas_loop_code(pheno_file, geno_file, snp_file, 
                                         file_output = TRUE)
cat(analysis_code)
```

#### 3. 表型文件结构检查

**问题：** 用户ID列位置不确定时，循环代码可能出错

**解决方案：**
```r
# 表型文件结构检查和性状提取标准模板
check_pheno_structure_and_extract_traits <- function(pheno_file, 
                                                     target_traits = NULL,
                                                     max_traits = NULL) {
  
  # 读取表型数据
  myY <- read.table(pheno_file, header = TRUE)
  
  # 自动识别ID列
  id_info <- auto_detect_id_column(myY)
  
  cat("📊 表型文件结构分析：\n")
  cat("• 文件：", pheno_file, "\n")
  cat("• 总行数：", nrow(myY), "\n")
  cat("• 总列数：", ncol(myY), "\n")
  cat("• 识别到的ID列：", id_info$id_column, "（第", id_info$column_index, "列）\n")
  
  # 提取所有性状列
  all_trait_cols <- setdiff(colnames(myY), id_info$id_column)
  cat("• 所有性状列：", paste(all_trait_cols, collapse = ", "), "\n")
  
  # 检查缺失值
  missing_stats <- sapply(myY[, all_trait_cols, drop = FALSE], 
                          function(x) sum(is.na(x)))
  cat("• 缺失值统计：\n")
  for (trait in names(missing_stats)) {
    cat("  ", trait, ": ", missing_stats[trait], "个缺失值（", 
        round(missing_stats[trait]/nrow(myY)*100, 1), "%）\n")
  }
  
  # 确定要分析的性状
  if (!is.null(target_traits)) {
    # 使用用户指定的性状
    traits_to_analyze <- intersect(target_traits, all_trait_cols)
    if (length(traits_to_analyze) < length(target_traits)) {
      missing_traits <- setdiff(target_traits, all_trait_cols)
      cat("⚠️ 警告：以下性状在文件中不存在：", 
          paste(missing_traits, collapse = ", "), "\n")
    }
  } else if (!is.null(max_traits)) {
    # 限制分析的最大性状数
    traits_to_analyze <- all_trait_cols[1:min(max_traits, length(all_trait_cols))]
  } else {
    # 分析所有性状
    traits_to_analyze <- all_trait_cols
  }
  
  cat("• 将要分析的性状：", paste(traits_to_analyze, collapse = ", "), "\n")
  
  # 生成性状数据框
  trait_data_list <- list()
  for (trait in traits_to_analyze) {
    trait_data <- myY[, c(id_info$id_column, trait)]
    colnames(trait_data) <- c("Taxa", trait)
    trait_data_list[[trait]] <- trait_data
  }
  
  return(list(
    id_info = id_info,
    all_traits = all_trait_cols,
    traits_to_analyze = traits_to_analyze,
    trait_data_list = trait_data_list,
    original_data = myY
  ))
}

# 使用示例：只分析前两个性状
pheno_info <- check_pheno_structure_and_extract_traits(
  pheno_file = "phenotype.csv",
  max_traits = 2
)

# 生成循环分析代码
cat("📝 生成分析代码（只分析前两个性状）...\n")
for (trait in pheno_info$traits_to_analyze) {
  cat("\n# 分析性状：", trait, "\n")
  cat("Y_", trait, " <- pheno_info$trait_data_list[[\"", trait, "\"]]\n", sep = "")
  cat("myGAPIT_", trait, " <- GAPIT(\n", sep = "")
  cat("  Y = Y_", trait, ",\n", sep = "")
  cat("  GD = myGD,\n")
  cat("  GM = myGM,\n")
  cat("  PCA.total = 3,\n")
  cat("  model = c(\"BLINK\"),\n")
  cat("  file.output = TRUE,\n")
  cat("  Multiple_analysis = FALSE\n")
  cat(")\n")
}
```

#### 4. 改进总结

基于用户反馈，GAPIT Expert Skill在以下方面进行了优化：

1. **文件名验证强化**：
   - 主动检查文件是否存在
   - 提供相似文件建议
   - 用户交互式确认

2. **参数说明明确化**：
   - 明确说明file.output参数的重要性
   - 区分TRUE/FALSE的不同行为
   - 提供手动保存结果的备选方案

3. **表型结构智能识别**：
   - 自动检测ID列位置
   - 智能提取性状列
   - 支持只分析指定数量的性状

4. **代码生成优化**：
   - 根据文件验证结果生成代码
   - 包含详细的注释和说明
   - 提供错误处理和备选方案

### Q13: GAPIT函数代码集成和问题诊断指南
**问题现象：** 用户希望智能体能够直接定位GAPIT函数的内部问题，理解函数实现细节，提供更准确的问题诊断

#### 1. 函数代码集成方案

**当前状态：**
- **技能包大小**: 96KB（不含函数代码）
- **函数代码大小**: 762KB（21,125行）
- **总大小**: 858KB（包含函数代码）

**集成策略：**
1. **核心函数摘要**：包含在技能包中（已创建`GAPIT_FUNCTION_SUMMARY.md`）
2. **完整函数代码**：作为可选附件提供
3. **关键代码段**：在技能文档中引用重要函数部分

**优势：**
- **快速问题定位**：智能体可以直接查看函数实现
- **准确错误诊断**：理解内部逻辑，提供针对性解决方案
- **功能解释**：详细解释参数作用和算法原理
- **代码审查**：帮助用户理解GAPIT的内部工作机制

#### 2. 关键函数位置索引

**主函数位置：**
```r
# GAPIT主函数定义开始
`GAPIT` <- function(...) {  # 约第15,801行
  # 函数体...
}
```

**核心子函数位置：**
1. **`GAPIT.MLM()`**: 约第16,000-16,500行
2. **`GAPIT.FarmCPU()`**: 约第17,500-18,000行
3. **`GAPIT.BLINK()`**: 约第18,000-18,500行
4. **`GAPIT.Phenotype.Simulation()`**: 约第15,000-15,500行
5. **`GAPIT.Association()`**: 约第16,500-17,000行

#### 3. 常见问题诊断指南

**问题1：内存不足错误**
```r
# 相关代码位置：约第16,200-16,300行
# 大数据处理逻辑
if(nrow(GD) > 10000) {
  warning("Large dataset detected, consider using CMLM or FarmCPU for memory efficiency")
}
```

**问题2：收敛失败**
```r
# 相关代码位置：约第17,000-17,100行
# 收敛检查逻辑
if(iteration > max_iterations) {
  warning("Model failed to converge after ", max_iterations, " iterations")
}
```

**问题3：参数验证错误**
```r
# 相关代码位置：约第15,850-15,880行
# 参数检查逻辑
if(is.null(Y)) stop("Phenotype data (Y) is required!")
if(is.null(GD) & is.null(G)) stop("Genotype data (GD or G) is required!")
```

#### 4. 函数代码使用示例

**示例1：查看函数定义**
```r
# 智能体可以这样帮助用户理解函数
cat("GAPIT主函数定义开始于第15,801行\n")
cat("关键参数说明：\n")
cat("• Y: 表型数据，必须包含Taxa列\n")
cat("• GD: 数值型基因型数据（0,1,2编码）\n")
cat("• model: 分析模型，如'BLINK'、'FarmCPU'\n")
```

**示例2：诊断具体问题**
```r
# 当用户遇到"Error: object 'myGAPIT' not found"时
# 智能体可以检查相关代码位置
cat("这个错误通常发生在GAPIT函数内部对象创建失败时\n")
cat("相关代码位置：约第16,100-16,150行\n")
cat("可能原因：\n")
cat("1. 输入数据格式不正确\n")
cat("2. 内存不足导致对象创建失败\n")
cat("3. 参数设置冲突\n")
```

#### 5. 智能体使用指南

**5.1 如何利用函数代码**
1. **快速定位**：使用行号索引快速找到相关函数
2. **理解逻辑**：阅读函数实现理解算法原理
3. **诊断问题**：根据错误信息定位具体代码位置
4. **解释功能**：基于代码实现解释参数作用

**5.2 响应模式**
- **技术问题**：引用具体代码行，解释实现逻辑
- **参数疑问**：说明参数在函数中的具体作用
- **性能优化**：基于代码分析提供优化建议
- **错误诊断**：定位错误源，提供解决方案

**5.3 注意事项**
1. **代码更新**：函数代码可能随GAPIT版本更新而变化
2. **兼容性**：确保引用的代码行与当前版本一致
3. **解释准确**：基于代码实现提供准确的技术解释
4. **用户友好**：将技术细节转化为用户易懂的语言

#### 6. 代码修改管理机制

**6.1 智能体代码修改处理流程**

```
开始
├── 用户提出可能涉及代码修改的需求
├── 智能体明确提示：是否改变原始GAPIT代码？
│   ├── 用户确认修改 → 继续
│   └── 用户拒绝 → 提供替代方案
├── 评估修改合理性和必要性
│   ├── 合理必要 → 继续
│   └── 不合理 → 拒绝并解释原因
├── 创建原始GAPIT代码备份
├── 实施代码修改
├── 验证修改效果
├── 在反馈信息模板中记录修改详情
├── 智能体甄别修改代码，提出改进方案
├── 上报创造者（您）沟通确认
│   ├── 大多数人都需求且符合GAPIT发展方向 → 更新整体GAPIT代码
│   └── 不是绝大多数人需求或不符合发展方向 → 隐藏修改
└── 返回给用户修改处理结果
```

**6.2 代码修改甄别机制**

智能体完成代码修改后，必须进行以下甄别：

```r
# 代码修改甄别报告模板
generate_modification_report <- function(modification_details) {
  report <- list(
    # 1. 修改内容摘要
    summary = paste("修改了", modification_details$function_name, 
                   "函数，位置：", modification_details$location),
    
    # 2. 技术合理性评估
    technical_assessment = list(
      implementation_reasonable = TRUE,  # 技术实现是否合理
      algorithm_correct = TRUE,          # 算法逻辑是否正确
      code_quality = "good"              # 代码质量评估
    ),
    
    # 3. 兼容性影响分析
    compatibility_impact = list(
      existing_functions = "no_impact",  # 对现有功能的影响
      data_formats = "no_impact",        # 对数据格式的影响
      parameter_settings = "no_impact"   # 对参数设置的影响
    ),
    
    # 4. 性能影响评估
    performance_impact = list(
      computation_time = "unchanged",    # 计算时间变化
      memory_usage = "unchanged",        # 内存使用变化
      scalability = "unchanged"          # 可扩展性变化
    ),
    
    # 5. 改进建议
    improvement_suggestions = c(
      "建议添加更多错误处理",
      "可以考虑优化算法效率"
    ),
    
    # 6. 社区价值评估
    community_value = list(
      user_demand = "medium",            # 用户需求程度
      alignment_with_roadmap = TRUE,     # 是否符合GAPIT发展方向
      potential_impact = "moderate"      # 潜在影响范围
    )
  )
  
  return(report)
}
```

**6.3 上报创造者决策标准**

智能体需要将代码修改上报给创造者（您）进行决策：

| 决策因素 | 更新整体代码 | 隐藏修改 | 保留用户特定版本 |
|----------|--------------|----------|------------------|
| **用户需求** | 大多数用户需求 | 少数用户需求 | 特定用户需求 |
| **发展方向** | 符合GAPIT发展方向 | 不符合发展方向 | 中立 |
| **技术影响** | 正面影响，无副作用 | 可能有副作用 | 影响有限 |
| **维护成本** | 维护成本低 | 维护成本高 | 用户自行维护 |

**6.4 智能体代码修改处理指南**

**修改请求识别和提示：**
智能体必须明确提示用户：
```
[智能体提示] 您的需求可能需要修改原始GAPIT代码。是否确认进行代码修改？
- 确认：智能体将创建原始代码备份，然后实施修改
- 拒绝：智能体将提供替代方案或解释限制
```

**风险评估内容：**
- **兼容性风险**：修改可能影响与其他软件的兼容性
- **稳定性风险**：修改可能引入新的错误或不稳定因素
- **维护风险**：修改可能增加代码维护的复杂性
- **升级风险**：修改可能影响未来版本的升级

**用户确认要求：**
- **明确同意**：用户必须明确同意修改原始代码
- **风险认知**：用户必须确认已了解修改可能带来的风险
- **备份确认**：用户必须确认已创建原始代码备份
- **责任承担**：用户必须确认愿意承担修改带来的后果

#### 7. 文件大小管理策略

**当前状态：**
- GAPIT函数代码：762KB
- 技能包总大小：约1MB
- **可接受范围**：5MB以下

**管理策略：**
1. **保持摘要文档**：GAPIT_FUNCTION_SUMMARY.md（函数摘要）
2. **保留原始代码**：gapit_functions.txt（完整函数代码）
3. **优化反馈模板**：FEEDBACK_TEMPLATE.md（包含代码修改记录）
4. **排除大文件**：不包含user manual等大文件
5. **压缩优化**：使用高效压缩算法减少包大小

#### 8. 最佳实践总结

**8.1 代码修改前**
1. **充分沟通**：与用户充分沟通修改需求和预期效果
2. **风险评估**：详细评估修改可能带来的风险
3. **备份创建**：务必创建原始代码的完整备份
4. **测试计划**：制定详细的测试计划

**8.2 代码修改中**
1. **最小修改**：尽量保持最小修改原则
2. **注释添加**：添加详细的修改注释
3. **兼容性保持**：保持与现有功能的兼容性
4. **错误处理**：添加适当的错误处理机制

**8.3 代码修改后**
1. **功能验证**：验证修改是否达到预期效果
2. **性能测试**：测试修改对性能的影响
3. **兼容性测试**：测试与现有功能的兼容性
4. **文档更新**：更新相关文档和说明

**8.4 上报创造者**
1. **详细报告**：提供详细的修改报告
2. **风险评估**：提供完整的风险评估
3. **用户反馈**：收集和提供用户反馈
4. **决策建议**：提供决策建议和理由

通过这种机制，智能体可以在包含完整GAPIT函数代码的同时，建立完善的代码修改管理流程，确保代码修改的合理性、安全性和可追溯性。

```r
# 当用户遇到"object 'X' not found"错误时
diagnose_object_not_found <- function(error_message) {
  cat("错误诊断：", error_message, "\n")
  cat("可能原因：\n")
  cat("1. 变量名拼写错误\n")
  cat("2. 数据未正确加载\n")
  cat("3. 函数内部变量作用域问题\n")
  
  # 提供解决方案
  cat("\n解决方案：\n")
  cat("1. 检查变量名拼写\n")
  cat("2. 确认数据加载步骤\n")
  cat("3. 查看函数内部变量定义（约第15,850行）\n")
}
```

**示例3：解释算法逻辑**
```r
# 解释BLINK算法核心
explain_blink_algorithm <- function() {
  cat("BLINK算法核心逻辑：\n")
  cat("1. 初始化：设置初始固定效应为空\n")
  cat("2. 迭代：重复以下步骤直到收敛\n")
  cat("   a. 使用当前固定效应进行关联分析\n")
  cat("   b. 选择显著标记作为新的固定效应\n")
  cat("   c. 更新固定效应列表\n")
  cat("3. 输出：返回最终GWAS结果\n")
  
  cat("\n相关代码位置：约第18,000-18,500行\n")
}
```

#### 5. 智能体使用函数代码的指南

**1. 问题定位流程：**
```r
# 智能体诊断问题的标准流程
diagnose_gapit_problem <- function(error_type, user_context) {
  # 步骤1：识别错误类型
  error_patterns <- list(
    memory = "cannot allocate vector",
    convergence = "convergence failed",
    parameter = "object.*not found"
  )
  
  # 步骤2：定位相关代码
  code_locations <- list(
    memory = "第16,200-16,300行",
    convergence = "第17,000-17,100行",
    parameter = "第15,850-15,880行"
  )
  
  # 步骤3：提供解决方案
  solutions <- list(
    memory = "增加内存限制或使用内存优化模型",
    convergence = "调整模型参数或增加迭代次数",
    parameter = "检查参数名称和数据加载"
  )
  
  # 返回诊断结果
  return(list(
    error_type = error_type,
    code_location = code_locations[[error_type]],
    solution = solutions[[error_type]]
  ))
}
```

**2. 功能解释流程：**
```r
# 智能体解释功能的流程
explain_gapit_feature <- function(feature_name) {
  feature_explanations <- list(
    Multi_iter = "多步迭代参数，用于FarmCPU和BLINK模型的重新估计机制",
    buspred = "基因组选择预测开关，控制是否在GWAS后进行预测",
    lmpred = "预测方法选择，FALSE=GAGBLUP，TRUE=MAS",
    pv.cut = "标记排除阈值，默认排除20%的标记"
  )
  
  if(feature_name %in% names(feature_explanations)) {
    return(feature_explanations[[feature_name]])
  } else {
    return("未找到该功能的解释，请检查功能名称")
  }
}
```

**3. 代码审查流程：**
```r
# 智能体审查代码的流程
review_gapit_code <- function(code_section) {
  # 检查代码质量
  quality_checks <- list(
    error_handling = "检查是否有适当的错误处理",
    memory_management = "检查内存使用是否优化",
    algorithm_efficiency = "检查算法复杂度是否合理"
  )
  
  # 提供改进建议
  suggestions <- list(
    error_handling = "建议添加更多的tryCatch块",
    memory_management = "建议使用稀疏矩阵存储",
    algorithm_efficiency = "建议优化迭代收敛条件"
  )
  
  return(list(
    quality_checks = quality_checks,
    suggestions = suggestions
  ))
}
```

#### 6. 实施建议

**短期方案（推荐）：**
1. **包含函数摘要**：将`GAPIT_FUNCTION_SUMMARY.md`集成到技能包中
2. **提供代码索引**：在技能文档中添加关键函数位置信息
3. **创建诊断指南**：提供常见问题的诊断流程和解决方案

**中期方案：**
1. **选择性集成**：将最常用的核心函数（约500行）包含在技能包中
2. **动态加载**：根据需要从外部资源加载特定函数代码
3. **版本管理**：确保函数代码与用户安装的GAPIT版本一致

**长期方案：**
1. **完整集成**：将全部21,125行函数代码包含在技能包中
2. **智能分析**：基于函数代码进行深度问题诊断和优化建议
3. **实时更新**：与GAPIT GitHub仓库同步，确保代码最新

#### 7. 优势总结

**包含函数代码的优势：**
1. **直接问题定位**：智能体可以直接查看函数实现，快速定位问题
2. **准确错误诊断**：理解内部逻辑，提供针对性解决方案
3. **功能详细解释**：基于代码实现解释参数作用和算法原理
4. **代码审查能力**：帮助用户理解GAPIT的内部工作机制
5. **问题预防**：提前识别潜在问题，提供预防建议

**实施考虑：**
1. **文件大小**：当前技能包96KB，函数代码762KB，总大小858KB
2. **版本兼容**：需要确保函数代码与用户安装的GAPIT版本一致
3. **更新维护**：当GAPIT更新时，技能包中的函数代码需要同步更新
4. **知识产权**：确保有权限分发GAPIT的函数代码

#### 8. 推荐实施方案

基于平衡考虑，推荐以下实施方案：

**第一阶段（立即实施）：**
1. 将`GAPIT_FUNCTION_SUMMARY.md`集成到技能包中
2. 在SKILL.md中添加Q13章节（本文档）
3. 提供关键函数位置索引和诊断指南

**第二阶段（下次更新）：**
1. 选择性集成核心函数（主函数+关键子函数，约500行）
2. 创建动态代码加载机制
3. 添加版本兼容性检查

**第三阶段（长期规划）：**
1. 完整函数代码集成（可选附件）
2. 智能代码分析和优化建议
3. 实时同步更新机制

### Q14: GWAS方法power和FDR比较原理
**问题现象：** 用户需要理解GAPIT中各个GWAS方法的统计性能比较，特别是power和FDR的评估原理，以及为什么在GAPIT3中开放多种方法供用户对比

#### 1. power和FDR的基本概念

**power（检测功效）定义：**
- **计算方法**：使用模拟数据，设定固定的遗传力（h2）和QTN数目（NQTN）
- **探测规则**：所有GWAS结果标记按照P值从小到大的顺序排列
- **增加条件**：探测到一个真实的QTN（数量性状位点）
- **计算公式**：`power增加 = 1/NQTN`
- **解释**：NQTN是模拟数据中设定的总QTN数目，每探测到一个真实QTN，power就增加1/NQTN

**FDR（错误发现率）定义：**
- **计算方法**：在探测到真实QTN之前犯的错误次数
- **错误定义**：发现了假的位点（假阳性）
- **计算公式**：`FDR = 假位点数目 / 总标记数目`
- **解释**：衡量在发现真实信号之前犯了多少次错误

#### 2. 评估方法和比较原则

**核心比较原则：**
- **同等风险下比较**：在同样的FDR（风险水平）下，比较哪种方法的power最高
- **模拟数据基础**：依赖于大量重复试验，在相同的遗传力和QTN数目条件下得出结论
- **排序方法**：标记按照P值排序，依次判断是否为真实QTN

**评估流程：**
1. **数据模拟**：生成具有已知QTN位置的模拟数据
2. **方法运行**：用不同GWAS方法分析相同数据
3. **结果排序**：将每个方法的标记结果按P值从小到大排序
4. **逐个判断**：从最小P值开始，判断每个标记是否为真实QTN
5. **统计计算**：
   - 探测到真实QTN：power增加1/NQTN
   - 探测到假位点：FDR增加1/总标记数
6. **曲线绘制**：绘制power-FDR曲线，比较不同方法

#### 3. GAPIT中GWAS方法的power排序

**从弱到强的顺序：**
1. **GLM（广义线性模型）**：不考虑群体结构，power最低
2. **MLM（混合线性模型）**：校正群体结构，power有所提高
3. **SUPER（Settlement of MLM Under Progressively Exclusive Relationship）**：迭代优化，进一步提高power
4. **MLMM（Multiple Locus Mixed Model）**：同时考虑多个位点，power继续提升
5. **FarmCPU（Fixed and random model Circulating Probability Unification）**：固定和随机模型循环，power显著提高
6. **BLINK（Bayesian-information and Linkage-disequilibrium Iteratively Nested Keyway）**：贝叶斯框架，power最高

**技术演进逻辑：**
- **GLM → MLM**：从忽略群体结构到校正群体结构
- **MLM → SUPER**：从单次分析到迭代优化
- **SUPER → MLMM**：从单一位点到多位点同时考虑
- **MLMM → FarmCPU**：从混合模型到固定随机模型分离
- **FarmCPU → BLINK**：从频率学派到贝叶斯框架

#### 4. 现实数据的局限性

**模拟与现实的差异：**
1. **遗传结构复杂性**：现实数据的遗传结构比模拟数据复杂得多
2. **QTN数目未知**：现实数据中真实的QTN数目和位置未知
3. **群体异质性**：现实群体可能存在亚结构、选择压力等复杂因素
4. **环境互作**：现实数据中基因-环境互作影响显著

**方法表现的不可预测性：**
- **可能相反**：在模拟数据中power高的方法，在特定现实数据中可能表现不佳
- **数据依赖性**：方法表现高度依赖于具体数据的特性
- **无绝对最优**：没有一种方法在所有现实数据中都表现最优

#### 5. GAPIT3的设计理念

**多方法开放策略：**
1. **提供选择**：将多种GWAS方法开放给用户，让用户可以根据自己的数据特点选择
2. **对比验证**：鼓励用户对比不同方法的结果，寻找一致性信号
3. **灵活应用**：用户可以根据研究目标和数据特性选择合适的方法

**多方法相互验证：**
- **核心观点**：不能说一个位点同时被多个方法检测到，这个位点就更可信
- **实际意义**：但这种方法提供了暗示或创新的多方法相互验证角度
- **用户偏好**：这种设计让很多用户喜欢，因为它提供了更多的分析视角

**统计原理：**
- **独立性假设**：不同GWAS方法基于不同的统计假设和模型
- **一致性证据**：多个独立方法都检测到的信号，提供了更强的一致性证据
- **减少假阳性**：多方法一致性有助于减少方法特异性假阳性

#### 6. 实际应用建议

**方法选择策略：**
1. **初步筛选**：先用BLINK或FarmCPU进行初步分析，获得高power结果
2. **验证检查**：用MLM或SUPER验证显著位点，检查结果一致性
3. **保守分析**：对于关键发现，使用多种方法交叉验证

**结果解读指南：**
```r
# 多方法结果一致性检查示例
check_method_consistency <- function(gwas_results_list, threshold = 1e-5) {
  # 提取每个方法的显著位点
  significant_snps <- list()
  
  for(method_name in names(gwas_results_list)) {
    gwas_df <- gwas_results_list[[method_name]]
    sig_snps <- gwas_df[gwas_df$P.value < threshold, "SNP"]
    significant_snps[[method_name]] <- sig_snps
  }
  
  # 计算交集
  all_methods <- names(gwas_results_list)
  intersection_snps <- Reduce(intersect, significant_snps)
  
  # 生成报告
  report <- list(
    total_methods = length(all_methods),
    significant_in_all = length(intersection_snps),
    intersection_snps = intersection_snps,
    method_specific_counts = sapply(significant_snps, length)
  )
  
  return(report)
}

# 使用示例
# 假设有BLINK、FarmCPU、MLM三种方法的结果
gwas_results <- list(
  BLINK = read.csv("GAPIT.Association.GWAS_Results.BLINK.csv"),
  FarmCPU = read.csv("GAPIT.Association.GWAS_Results.FarmCPU.csv"),
  MLM = read.csv("GAPIT.Association.GWAS_Results.MLM.csv")
)

consistency_report <- check_method_consistency(gwas_results, threshold = 1e-5)
cat("多方法一致性报告：\n")
cat("• 总方法数：", consistency_report$total_methods, "\n")
cat("• 所有方法都显著的SNP数：", consistency_report$significant_in_all, "\n")
cat("• 各方法显著SNP数：\n")
for(method in names(consistency_report$method_specific_counts)) {
  cat("  ", method, ": ", consistency_report$method_specific_counts[[method]], "\n")
}
```

**交叉验证最佳实践：**
1. **至少两种方法**：对重要发现至少用两种不同原理的方法验证
2. **关注一致性**：特别关注被多种方法都检测到的位点
3. **考虑生物学**：结合生物学知识解释多方法一致性结果
4. **报告透明**：在论文中明确报告使用了哪些方法，以及结果的一致性情况

#### 7. 历史背景和理论基础

**方法发展历程：**
1. **早期阶段（2000-2005）**：GLM为主，简单快速但假阳性高
2. **结构校正阶段（2005-2010）**：MLM引入，校正群体结构
3. **迭代优化阶段（2010-2015）**：SUPER、MLMM发展，提高power
4. **模型分离阶段（2015-2020）**：FarmCPU出现，固定随机效应分离
5. **贝叶斯框架阶段（2020-至今）**：BLINK发展，贝叶斯框架提高准确性

**理论基础：**
- **统计遗传学**：混合线性模型、贝叶斯统计、多重检验校正
- **计算生物学**：高效算法、并行计算、大数据处理
- **群体遗传学**：连锁不平衡、群体结构、选择压力

**文献支持：**
- 大量研究论文比较不同GWAS方法的power和FDR
- GAPIT相关文献详细描述了各种方法的统计性能
- 模拟研究为方法比较提供了理论基础

#### 8. 总结

**核心要点：**
1. **power和FDR**：是评估GWAS方法统计性能的两个关键指标
2. **方法排序**：GAPIT中方法从GLM到BLINK，power逐渐增强
3. **现实局限性**：模拟结果的排序不一定适用于所有现实数据
4. **GAPIT3理念**：通过开放多种方法，提供多角度验证的可能性

**对用户的建议：**
- **理解原理**：理解power和FDR的计算方法和比较原则
- **灵活应用**：根据数据特点选择合适的方法，不盲目追求高power方法
- **多方法验证**：对重要发现进行多方法交叉验证
- **结合生物学**：将统计结果与生物学知识结合，做出合理判断

**未来发展方向：**
1. **更精确的评估**：开发更接近现实数据的模拟方法
2. **自适应方法**：根据数据特性自动选择最优GWAS方法
3. **集成学习**：结合多种方法的优势，提高检测准确性
4. **可解释AI**：提高GWAS结果的可解释性和生物学意义

---

**最后更新**：2026-06-17  
**维护者**：GAPIT开发团队  
**联系方式**：通过GAPIT交流群反馈问题

*注意：本技能会持续更新，建议定期检查新版本*
