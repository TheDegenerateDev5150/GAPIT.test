#!/bin/bash
# GAPIT专家技能微信群启动脚本
# 版本：1.0.0
# 更新日期：2026-06-04

set -e

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# 日志函数
log_info() {
    echo -e "${BLUE}[INFO]${NC} $(date '+%Y-%m-%d %H:%M:%S') - $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $(date '+%Y-%m-%d %H:%M:%S') - $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $(date '+%Y-%m-%d %H:%M:%S') - $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $(date '+%Y-%m-%d %H:%M:%S') - $1"
}

# 项目根目录
PROJECT_ROOT="/Users/Jiabo/Documents/trae_projects/GAPIT-Agent"
SKILL_DIR="$PROJECT_ROOT/.trae/skills/gapit-expert"

# 生成微信群分享内容
generate_wechat_content() {
    log_info "生成微信群分享内容..."
    
    local content_file="$SKILL_DIR/wechat_share_content.txt"
    
    cat > "$content_file" << 'EOF'
🎉 GAPIT专家技能测试邀请 🎉

各位GAPIT作者和用户：

我们开发了一个基于Trae IDE的GAPIT专家技能，现在邀请大家参与测试和训练！

📋 核心功能：
1. 解释GLM、MLM、CMLM、SUPER、MLMM、FarmCPU、BLINK等模型
2. 智能参数推荐和代码生成
3. 曼哈顿图、QQ图结果解读
4. 常见问题诊断和解决方案

🔧 安装方式（三选一）：

【方式一：自动安装脚本（推荐）】
```bash
# 下载安装脚本
curl -O [下载链接]/install_gapit_expert.sh

# 运行安装脚本
chmod +x install_gapit_expert.sh
./install_gapit_expert.sh
```

【方式二：手动安装】
1. 下载技能包：gapit-expert-skill.zip
2. 解压到Trae技能目录：
   ```bash
   # macOS/Linux
   unzip gapit-expert-skill.zip -d ~/.trae/skills/
   
   # Windows
   Expand-Archive gapit-expert-skill.zip -DestinationPath "$env:USERPROFILE\.trae\skills\"
   ```
3. 重启Trae IDE

【方式三：直接复制文件】
将.trae/skills/gapit-expert/目录复制到您的Trae技能目录中。

🎯 测试要求：
- 测试时间：建议1-2周
- 测试内容：各种GAPIT相关问题咨询
- 反馈方式：使用提供的反馈模板

📅 沟通安排：
- 微信群：日常问题讨论（本群）
- 定期会议：每周五下午3点进度同步
- 紧急问题：随时@技术支持

📁 文件下载：
- 技能包：[待补充下载链接]
- 安装指南：[待补充链接]
- 培训材料：[待补充链接]

⚠️ 注意事项：
1. 测试期间请记录遇到的问题
2. 使用反馈模板提交问题
3. 参与每周进度会议
4. 所有反馈仅用于技能优化

🙏 感谢您的参与！
您的专业知识和经验将对技能的优化至关重要。

有任何问题请随时在群内提问！
EOF
    
    log_success "微信群分享内容已生成：$content_file"
}

# 生成群公告
generate_group_announcement() {
    log_info "生成微信群公告..."
    
    local announcement_file="$SKILL_DIR/wechat_group_announcement.txt"
    
    cat > "$announcement_file" << 'EOF'
【群公告】GAPIT专家技能测试群

📌 群宗旨：
共同测试和优化GAPIT专家技能，为遗传关联分析提供智能化辅助支持。

🎯 测试目标：
1. 验证技能回答准确性和专业性
2. 发现功能缺陷和改进空间
3. 收集高质量对话数据用于训练
4. 建立标准化回答模板

🔧 安装步骤：
1. 下载技能包：gapit-expert-skill.zip
2. 按照安装指南完成安装
3. 重启Trae IDE开始测试

📋 测试内容：
- 模型解释测试（GLM、MLM、FarmCPU等）
- 参数推荐测试
- 代码生成测试
- 结果解读测试
- 问题诊断测试

📅 会议安排：
- 每周五下午3点：进度同步会议
- 会议内容：本周测试总结、问题讨论、下周计划
- 会议工具：腾讯会议/Zoom（链接会提前发布）

📝 反馈要求：
1. 使用标准化反馈模板
2. 详细描述问题和重现步骤
3. 提供期望结果和实际结果
4. 附上相关截图或日志

👥 角色分工：
- 群主/管理员：项目协调和问题升级
- 技术支持：技术问题解答和故障排除
- 测试协调：测试进度跟踪和反馈收集

📚 重要文档：
1. 安装指南：INSTALL.md
2. 培训材料：TESTER_TRAINING_GUIDE.md
3. 反馈模板：FEEDBACK_TEMPLATE.md
4. 问题跟踪：ISSUE_TRACKING.md

🚨 紧急联系：
- 技术问题：[待补充]
- 测试问题：[待补充]
- 项目协调：[待补充]

让我们共同努力，打造一个优秀的GAPIT专家助手！
EOF
    
    log_success "微信群公告已生成：$announcement_file"
}

# 生成常见问题解答
generate_faq() {
    log_info "生成常见问题解答..."
    
    local faq_file="$SKILL_DIR/wechat_faq.txt"
    
    cat > "$faq_file" << 'EOF'
🤔 GAPIT专家技能测试常见问题解答

Q1: 测试需要多长时间？
A: 建议每天测试30-60分钟，持续1-2周。具体时间可根据个人安排调整。

Q2: 需要提交多少测试数据？
A: 建议每周提交20-50个高质量问答对。质量比数量更重要。

Q3: 遇到技术问题怎么办？
A: 首先查看安装指南和常见问题，如无法解决，在微信群中提问或联系技术支持。

Q4: 测试数据如何保密？
A: 所有测试数据仅用于技能优化，会进行匿名化处理，不会公开个人信息。

Q5: 测试有报酬吗？
A: 根据测试贡献度提供相应奖励，包括软件授权、专业认可等。

Q6: 如何提交反馈？
A: 使用提供的反馈模板，通过邮件或在线表单提交。

Q7: 测试期间发现严重问题怎么办？
A: 立即在微信群中@技术支持，我们会优先处理。

Q8: 可以测试哪些内容？
A: 可以测试各种GAPIT相关问题，包括模型选择、参数设置、代码生成、结果解读等。

Q9: 需要什么环境？
A: 需要安装Trae IDE，操作系统可以是Windows、macOS或Linux。

Q10: 如何验证安装成功？
A: 重启Trae IDE后，在技能列表中查找"GAPIT Expert"，点击启动。

Q11: 测试期间需要记录什么？
A: 需要记录对话内容、遇到的问题、改进建议等。

Q12: 测试周期是多长？
A: 整个测试项目计划持续4-8周，根据进展调整。

Q13: 如何参与每周会议？
A: 会议链接会提前在群内发布，点击链接即可加入。

Q14: 测试完成后会怎样？
A: 我们会根据测试反馈优化技能，然后正式发布。

Q15: 如何获取最新版本？
A: 测试期间我们会定期更新，更新通知会在群内发布。
EOF
    
    log_success "常见问题解答已生成：$faq_file"
}

# 生成测试场景示例
generate_test_scenarios() {
    log_info "生成测试场景示例..."
    
    local scenarios_file="$SKILL_DIR/wechat_test_scenarios.txt"
    
    cat > "$scenarios_file" << 'EOF'
🧪 GAPIT专家技能测试场景示例

【场景1：基础模型咨询】
用户：我想做GWAS分析，应该选择哪个模型？
技能：这取决于您的数据类型和样本特征...

【场景2：参数优化咨询】
用户：我的数据有200个样本，1000个标记，PCA应该选几个成分？
技能：对于200个样本，建议PCA.total=3-5...

【场景3：结果解读咨询】
用户：我的曼哈顿图显示很多假阳性信号，怎么办？
技能：这可能由于群体结构未充分校正...

【场景4：代码生成请求】
用户：请帮我生成一个基本的MLM分析代码
技能：以下是使用MLM模型的GAPIT分析代码...

【场景5：问题诊断咨询】
用户：运行GAPIT时出现"内存不足"错误，怎么解决？
技能：可以尝试以下方法：1. 增加R内存限制...

【场景6：数据准备咨询】
用户：我的基因型数据是VCF格式，需要转换成什么格式？
技能：GAPIT支持HapMap格式，可以使用vcftools转换...

【场景7：高级功能咨询】
用户：如何进行多性状联合分析？
技能：GAPIT支持多性状分析，可以使用mvGAPIT函数...

【场景8：性能优化咨询】
用户：分析大数据时速度很慢，如何优化？
技能：可以尝试：1. 使用CMLM或FarmCPU模型...

【场景9：结果验证咨询】
用户：如何验证GWAS结果的可靠性？
技能：建议：1. 使用不同模型交叉验证...

【场景10：后续分析咨询】
用户：找到显著位点后，下一步该做什么？
技能：可以进行：1. 基因注释和功能预测...
EOF
    
    log_success "测试场景示例已生成：$scenarios_file"
}

# 生成文件上传指南
generate_upload_guide() {
    log_info "生成文件上传指南..."
    
    local upload_guide_file="$SKILL_DIR/file_upload_guide.md"
    
    cat > "$upload_guide_file" << 'EOF'
# 文件上传和分享指南

## 上传选项

### 选项1：GitHub Releases（推荐）
**优点**：版本管理、自动更新、访问稳定
**步骤**：
1. 创建GitHub仓库（如：gapit-expert-skill）
2. 创建Release：
   ```bash
   gh release create v1.0.0 gapit-expert-skill.zip \
     --title "GAPIT专家技能v1.0.0" \
     --notes "初始测试版本"
   ```
3. 获取下载链接：
   - `https://github.com/[用户名]/gapit-expert-skill/releases/download/v1.0.0/gapit-expert-skill.zip`

### 选项2：网盘分享
**百度网盘**：
1. 上传`gapit-expert-skill.zip`
2. 生成分享链接
3. 设置提取码（可选）
4. 有效期：建议设置永久

**Google Drive**：
1. 上传文件到Google Drive
2. 设置分享权限：知道链接的任何人可查看
3. 获取分享链接

### 选项3：自建服务器
**使用Python简单HTTP服务器**：
```bash
# 在包含文件的目录运行
python3 -m http.server 8000
```
访问：`http://[服务器IP]:8000/gapit-expert-skill.zip`

### 选项4：直接发送（小范围）
**微信文件传输**：
- 最大文件限制：通常100MB
- 建议：压缩后文件大小应小于100MB

## 文件清单

需要上传的文件：
1. `gapit-expert-skill.zip` - 主技能包
2. `install_gapit_expert.sh` - 安装脚本
3. 所有.md文档文件

## 访问链接格式

建议使用以下格式提供链接：

```
📁 文件下载：

主技能包：
https://[域名]/gapit-expert-skill.zip

安装脚本：
https://[域名]/install_gapit_expert.sh

文档查看：
https://[域名]/INSTALL.md
```

## 更新策略

1. **版本命名**：v1.0.0, v1.0.1, v1.1.0等
2. **更新通知**：在微信群中发布更新公告
3. **兼容性**：确保新版本向后兼容
4. **回滚方案**：准备旧版本下载链接

## 安全注意事项

1. **文件校验**：提供MD5或SHA256校验码
2. **访问控制**：敏感文件设置访问权限
3. **备份策略**：定期备份重要文件
4. **监控日志**：监控文件下载情况
EOF
    
    log_success "文件上传指南已生成：$upload_guide_file"
}

# 主函数
main() {
    log_info "开始准备微信群分享材料..."
    echo ""
    
    # 1. 生成微信群分享内容
    generate_wechat_content
    echo ""
    
    # 2. 生成群公告
    generate_group_announcement
    echo ""
    
    # 3. 生成常见问题解答
    generate_faq
    echo ""
    
    # 4. 生成测试场景示例
    generate_test_scenarios
    echo ""
    
    # 5. 生成文件上传指南
    generate_upload_guide
    echo ""
    
    log_success "所有微信群分享材料已准备完成！"
    echo ""
    echo "📋 生成的文件："
    echo "  1. wechat_share_content.txt - 微信群分享内容"
    echo "  2. wechat_group_announcement.txt - 群公告"
    echo "  3. wechat_faq.txt - 常见问题解答"
    echo "  4. wechat_test_scenarios.txt - 测试场景示例"
    echo "  5. file_upload_guide.md - 文件上传指南"
    echo ""
    echo "🎯 下一步行动："
    echo "  1. 将技能包上传到可访问的位置"
    echo "  2. 在微信群中发送分享内容"
    echo "  3. 设置群公告和管理规则"
    echo "  4. 启动测试和收集反馈"
    echo ""
    echo "💡 提示：您可以直接复制wechat_share_content.txt中的内容到微信群发送"
}

# 执行主函数
main "$@"