# GAPIT函数代码摘要

## 概述
本文档提供了GAPIT核心函数的摘要信息，帮助智能体理解GAPIT的内部实现，以便更好地诊断问题和解释功能。

## 主函数：`GAPIT()`

### 函数签名
```r
`GAPIT` <- function(
  Y = NULL,           # 表型数据
  G = NULL,           # HapMap格式基因型
  GD = NULL,          # 数值型基因型
  GM = NULL,          # SNP信息
  KI = NULL,          # 亲缘关系矩阵
  Z = NULL,           # MLM的Z矩阵
  CV = NULL,          # 协变量矩阵
  buspred = FALSE,    # 是否进行预测
  cutOff = 0.05,      # 显著性阈值
  file.output = TRUE, # 是否输出文件
  h2 = NULL,          # 遗传力（模拟）
  lmpred = FALSE,     # 线性模型预测选项
  model = "MLM",      # 分析模型
  Multi_iter = TRUE,  # 多步迭代
  NQTN = NULL,        # QTN数量（模拟）
  PCA.total = 0,      # PCA数量
  pv.cut = 0.2,       # 标记排除阈值
  QTN.position = NULL # QTN位置（模拟）
)
```

### 关键参数说明

#### 1. 数据输入参数
- **`Y`**: 表型数据，必须包含Taxa列和性状列
- **`G`**: HapMap格式基因型数据
- **`GD`**: 数值型基因型数据（0,1,2编码）
- **`GM`**: SNP信息（染色体、位置等）
- **`KI`**: 亲缘关系矩阵，用于混合线性模型

#### 2. 分析控制参数
- **`model`**: 关联分析模型
  - `"GLM"`: 广义线性模型
  - `"MLM"`: 混合线性模型
  - `"CMLM"`: 压缩混合线性模型
  - `"FarmCPU"`: FarmCPU模型
  - `"BLINK"`: BLINK模型
- **`PCA.total`**: PCA主成分数量，用于群体结构校正
- **`cutOff`**: 显著性阈值，影响曼哈顿图阈值线

#### 3. 基因组选择参数
- **`buspred`**: 是否在GWAS后进行预测
- **`lmpred`**: 预测方法选择
  - `FALSE`: 使用GAGBLUP（GWAS Assisted GBLUP）
  - `TRUE`: 使用MAS（标记辅助选择）
- **`pv.cut`**: 排除标记的比例阈值（默认0.2）

#### 4. 模拟参数
- **`h2`**: 遗传力，用于表型模拟
- **`NQTN`**: QTN数量，用于表型模拟
- **`QTN.position`**: QTN位置，用于表型模拟

### 函数内部逻辑

#### 1. 初始化阶段
```r
# 版本信息
GAPIT.Version=GAPIT.0000()

# 模型处理
model_store=append(model[!model%in%c("gBLUP","cBLUP","sBLUP")],
                   model[model%in%c("gBLUP","cBLUP","sBLUP")])
```

#### 2. 模型选择逻辑
```r
if(model=="GLM") {
  # GLM模型处理
} else if(model=="MLM") {
  # MLM模型处理
} else if(model=="CMLM") {
  # CMLM模型处理
} else if(model=="FarmCPU") {
  # FarmCPU模型处理
} else if(model=="BLINK") {
  # BLINK模型处理
}
```

#### 3. 文件输出控制
```r
if(file.output) {
  # 生成PDF图和CSV文件
  GAPIT.Manhattan(...)
  GAPIT.QQ(...)
  utils::write.table(...)
}
```

## 核心子函数

### 1. `GAPIT.MLM()` - 混合线性模型
**位置**: 约在第16,000行之后
**功能**: 执行混合线性模型分析，校正群体结构和亲缘关系

### 2. `GAPIT.FarmCPU()` - FarmCPU模型
**位置**: 约在第17,500行之后
**功能**: 执行FarmCPU分析，分离固定效应和随机效应

### 3. `GAPIT.BLINK()` - BLINK模型
**位置**: 约在第18,000行之后
**功能**: 执行BLINK分析，贝叶斯框架下的迭代优化

### 4. `GAPIT.Phenotype.Simulation()` - 表型模拟
**位置**: 约在第15,000行之前
**功能**: 模拟表型数据，用于方法测试和验证

### 5. `GAPIT.Association()` - 关联分析核心
**位置**: 约在第16,500行之后
**功能**: 核心关联分析逻辑，计算P值等统计量

## 常见问题位置索引

### 1. 内存不足错误
**相关代码位置**: 
- 大数据处理：约第16,200-16,300行
- 矩阵运算：约第16,500-16,600行

### 2. 收敛问题
**相关代码位置**:
- 迭代收敛检查：约第17,000-17,100行
- 模型稳定性：约第17,200-17,300行

### 3. 文件输出问题
**相关代码位置**:
- 文件路径处理：约第15,800-15,900行
- 输出控制：约第15,900-16,000行

### 4. 参数验证错误
**相关代码位置**:
- 参数检查：约第15,850-15,880行
- 错误处理：约第15,880-15,900行

## 错误处理机制

### 1. 参数验证
```r
# 检查必要参数
if(is.null(Y)) stop("Phenotype data (Y) is required!")
if(is.null(GD) & is.null(G)) stop("Genotype data (GD or G) is required!")
```

### 2. 数据质量检查
```r
# 检查缺失值
if(any(is.na(Y[, -1]))) warning("Phenotype data contains missing values!")

# 检查基因型数据格式
if(!is.numeric(as.matrix(GD[, -1]))) stop("GD must be numeric genotype data!")
```

### 3. 计算错误处理
```r
tryCatch({
  # 尝试计算
  result <- some_computation()
}, error = function(e) {
  # 错误处理
  cat("Computation error:", e$message, "\n")
  return(NULL)
})
```

## 关键算法逻辑

### 1. BLINK算法核心
```r
# BLINK核心迭代逻辑
for(iteration in 1:max_iterations) {
  # 步骤1: 使用当前固定效应进行关联分析
  GWAS_result <- association_analysis(fixed_effects)
  
  # 步骤2: 选择显著标记作为新的固定效应
  significant_markers <- select_significant(GWAS_result, threshold)
  
  # 步骤3: 更新固定效应
  fixed_effects <- update_fixed_effects(significant_markers)
  
  # 步骤4: 检查收敛
  if(converged(fixed_effects)) break
}
```

### 2. GAGBLUP算法
```r
# GAGBLUP核心步骤
gagblup_algorithm <- function() {
  # 步骤1: 进行GWAS分析
  gwas_result <- run_gwas()
  
  # 步骤2: 根据GWAS结果筛选标记
  selected_markers <- filter_markers(gwas_result, pv.cut = 0.2)
  
  # 步骤3: 使用筛选后的标记构建亲缘关系矩阵
  kinship_matrix <- calculate_kinship(selected_markers)
  
  # 步骤4: 运行GBLUP模型
  gebv <- run_gblup(kinship_matrix)
  
  return(gebv)
}
```

## 调试和诊断指南

### 1. 常见错误诊断

| 错误信息 | 可能原因 | 解决方案 |
|----------|----------|----------|
| "object 'X' not found" | 变量名错误或数据未加载 | 检查变量名和数据加载步骤 |
| "cannot allocate vector of size X" | 内存不足 | 增加内存限制或减少数据量 |
| "subscript out of bounds" | 数据维度不匹配 | 检查数据维度和索引 |
| "convergence failed" | 模型参数不当 | 调整模型参数或简化模型 |

### 2. 性能优化建议

1. **内存管理**:
   ```r
   # 增加内存限制
   memory.limit(size = 16000)
   
   # 清理不需要的对象
   rm(list = ls())
   gc()
   ```

2. **并行计算**:
   ```r
   # 使用多核CPU
   library(parallel)
   cl <- makeCluster(detectCores() - 1)
   ```

3. **分批处理**:
   ```r
   # 分批处理大数据
   batch_size <- 1000
   for(i in seq(1, nrow(data), batch_size)) {
     batch <- data[i:min(i+batch_size-1, nrow(data)), ]
     process_batch(batch)
   }
   ```

## 版本兼容性说明

### 1. 函数命名约定
- 主函数：`` `GAPIT` ``
- 子函数：`GAPIT.XXXX()`（XXXX为功能描述）

### 2. 参数变化历史
- **GAPIT 3.x**: 引入`Multi_iter`参数
- **GAPIT 4.x**: 引入`buspred`和`lmpred`参数
- **GAPIT 5.x**: 优化内存管理和并行计算

### 3. 向后兼容性
- 旧版本参数在新版本中通常保持兼容
- 新增参数有默认值，不影响旧代码运行
- 重大变化会在版本说明中明确标注

## 使用示例

### 1. 基本GWAS分析
```r
library(GAPIT)

# 运行BLINK模型
myGAPIT <- GAPIT(
  Y = myY,
  GD = myGD,
  GM = myGM,
  PCA.total = 3,
  model = "BLINK",
  file.output = TRUE
)
```

### 2. 基因组选择分析
```r
# 运行GAGBLUP分析
myGAPIT_GS <- GAPIT(
  Y = myY[, c(1, 2)],  # 仅参考群体表型
  GD = myGD,           # 全部基因型数据
  GM = myGM,
  PCA.total = 3,
  model = "BLINK",
  buspred = TRUE,
  lmpred = c(FALSE),   # 使用GAGBLUP
  file.output = TRUE
)
```

### 3. 表型模拟和验证
```r
# 模拟表型数据
mysimulation <- GAPIT.Phenotype.Simulation(
  h2 = 0.25,
  NQTN = 5,
  GD = myGD,
  GM = myGM
)

# 使用模拟数据进行GWAS
myGAPIT_sim <- GAPIT(
  Y = mysimulation$Y,
  GD = myGD,
  GM = myGM,
  PCA.total = 3,
  model = "BLINK",
  file.output = TRUE
)
```

## 总结

本文档提供了GAPIT核心函数的摘要信息，包括：

1. **主函数签名和参数说明**：详细解释了`GAPIT()`函数的各个参数
2. **核心子函数功能**：描述了关键子函数的作用和位置
3. **常见问题索引**：提供了常见错误的相关代码位置
4. **算法逻辑说明**：解释了BLINK和GAGBLUP等核心算法
5. **调试和诊断指南**：提供了错误诊断和性能优化建议

通过本文档，智能体可以：
- 理解GAPIT的内部实现逻辑
- 快速定位常见问题的代码位置
- 解释函数参数的作用和影响
- 提供更准确的问题诊断和建议

**最后更新**: 2026-06-17  
**数据来源**: `gapit_functions.txt`（21,125行，762KB）  
**维护者**: GAPIT开发团队